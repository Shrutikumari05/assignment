package Step_defination;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.hooks.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1.BaseTest;
import com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1.page1;
import com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1.page2;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class stepdefination_1{
	private BaseTest baseTest; // To manage WebDriver
    private page1 obj;
    Logger log;
    
   public stepdefination_1() {
	   baseTest = new BaseTest(); // Initialize BaseTest
   obj = new page1(baseTest.getDriver()); 
   log=Logger.getLogger(stepdefination_1.class);
   }// Pass WebD
   
	   
   
	
	@Given("I am on homepage of PHP Travels homepage")
public void I_am_on_homepage_of_PHP_Travels_homepage() {
	obj.Launch_app();
	log.info("pass");
	
}


@When("I should see Featured Flight section")
public void I_should_see_Featured_Flight_section() {
	
	System.out.println("Wel-Come");
}





@When("I press the down key")
public void I_press_the_down_key() {
	obj.arrow_down();
}




@When("I select the first flight displayed")
public void I_select_the_first_flight_displayed() {
	obj.select_lahor();
}


@Then("I see flight details page")
public void I_see_flight_details_page() {
	System.out.println("This is list of Featured_Flights");
}

}


