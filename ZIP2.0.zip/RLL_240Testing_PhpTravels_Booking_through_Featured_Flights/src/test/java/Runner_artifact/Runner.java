package Runner_artifact;




import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;


@CucumberOptions(
		
		features="src/test/resource/Feature",
        glue="Step_defination"	,
        tags="@Featured.feature" 
		)


public class Runner extends AbstractTestNGCucumberTests{

}
