package com.hooks.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class BaseTest {
    protected WebDriver driver; // Accessible to other classes via getter

    @Before
    public void setUp() {
       //System.setProperty("webdriver.edge.driver", "path/to/msedgedriver"); 
        driver = new EdgeDriver();
        driver.manage().window().maximize();
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    
    public WebDriver getDriver() {
        return driver; // Getter for the driver
    }
}