package com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

import com.hooks.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1.BaseTest;

public class page1{
	
	

	private WebDriver driver;

	By Flight_Click=By.xpath("//a[contains(text(),\"Flights\")]");
	By lahor_dubai_click=By.xpath("(//p[@class=\"m-0 text-hover\"])[1]");

	public page1(WebDriver driver) { // Constructor to inject WebDriver
        this.driver = driver;
    }
	
	public void Launch_app() {
		driver=new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://phptravels.net/");
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/flights");
	}


	public void flight_click() throws InterruptedException  {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	driver.findElement(Flight_Click).click();
	Thread.sleep(3000);
	}
	public void arrow_down() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	Actions actions = new Actions(driver);
    actions.sendKeys(Keys.ARROW_DOWN).perform();}
    
    public void select_lahor() {
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	driver.findElement(lahor_dubai_click).click();
	

	}
	
	

	}

	





