package com.myhooks.RLL_240Testing_PhpTravels_SignUP;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class DemoHooks {
	
    @Before
    
    public void precondition(){
    // instanciate WebDriver
    
    
    // Launch the app
    
    }

    @After
    
    public void postcondition(){
    // close browser
    
    }


}
