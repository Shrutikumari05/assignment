package com.pages.RLL_240Testing_PhpTravels_SignUP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class PhpTravels_SignUP_lib {
	
	WebDriver driver;
	By Account = By.xpath("//strong[contains(text(),\"Account\")]");
	By signup=By.xpath("//strong[contains(text(),\"Signup\")]");
	By firstname=By.xpath("//input[@id=\"firstname\"]");
	By lastname=By.xpath("//input[@id=\"last_name\"]");
	By select_country=By.xpath("//select[@name=\"phone_country_code\"]");
	By phone_no=By.xpath("//input[@id=\"phone\"]");
	By email=By.xpath("//input[@id=\"user_email\"]");
	By password=By.xpath("//input[@id=\"password\"]");
	By	checkbox=By.xpath("//span[@id=\"recaptcha-anchor\"]");
    By	button=By.xpath("//button[@id=\"submitBTN\"]");
    
    By countyname=By.xpath("//span[contains(text(),\"Algeria \")]");

	public void  PhpTravels_SignUP_lib(WebDriver driver) {
		this.driver=driver;
	}
	
	public void  launch_app() {
		driver.get("https://phptravels.net/");
		driver.manage().window().maximize();
		
	}
	
//	public void selectAccount() {
//		driver.findElement(Account).click();
//		  Select accountDropdown = new Select(driver.findElement(Account));
//	        accountDropdown.selectByVisibleText("Signup");
//	}
	
	
	public void selectAccount() throws InterruptedException {
	driver.findElement(Account).click();
	Thread.sleep(1000);
	driver.findElement(signup).click();

	}
	
	 public void filltheDetails(String firstName, String lastName , String phoneNumber, String emailAddress, String userPassword) {
	        driver.findElement(firstname).sendKeys(firstName);
	        driver.findElement(lastname).sendKeys(lastName);
	        
//	        Select countryDropdown = new Select(driver.findElement(select_country));
//	        countryDropdown.selectByVisibleText("Algeria");
	        
	        driver.findElement(phone_no).sendKeys(phoneNumber);
	        driver.findElement(email).sendKeys(emailAddress);
	        driver.findElement(password).sendKeys(userPassword);
	      
	        
	    }
	 public void selectcounty() {
		 driver.findElement(select_country).click();
	   driver.findElement(countyname).click();
	 }

	 public void clickcheckbox() {
		  driver.findElement(checkbox).click(); 
	 }
	 
	 public void submitpart()
	 {
		 driver.findElement(button).click(); 
	 }
		 

}
