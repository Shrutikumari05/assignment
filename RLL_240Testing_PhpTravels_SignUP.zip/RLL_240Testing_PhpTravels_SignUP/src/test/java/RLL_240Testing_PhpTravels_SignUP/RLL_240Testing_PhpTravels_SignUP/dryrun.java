package RLL_240Testing_PhpTravels_SignUP.RLL_240Testing_PhpTravels_SignUP;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_PhpTravels_SignUP.PhpTravels_SignUP_lib;



public class dryrun {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver;
		
		 driver = new ChromeDriver();
		 
		 PhpTravels_SignUP_lib obj1=new PhpTravels_SignUP_lib ();
		 obj1.PhpTravels_SignUP_lib(driver);
		 obj1.launch_app();
		 Thread.sleep(2000);
		 obj1.selectAccount();
		 obj1.filltheDetails("shruti","kumari", "67894242","shruti@gmail.com", "1234");
		 obj1.selectcounty();
		 Thread.sleep(5000);
		 obj1.clickcheckbox();
		 obj1.submitpart();
				
			
	}

}
