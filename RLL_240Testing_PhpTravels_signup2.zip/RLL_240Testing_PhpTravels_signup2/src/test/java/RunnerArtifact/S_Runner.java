package RunnerArtifact;
org.junit.runner.RunWith;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
  @CucumberOptions(
		  features="src/test/resource/com/resourses",
		  glue="stepDefinition",
		  tags="@home or @validData"
		  )
  
  public class S_Runner {
  
}
