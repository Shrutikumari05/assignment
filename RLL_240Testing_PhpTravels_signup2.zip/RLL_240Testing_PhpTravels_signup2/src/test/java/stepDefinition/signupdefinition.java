package stepDefinition;
import java.io.FileReader;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.signup;


import io.cucumber.java.en.*;


	public class signupdefinition {
			WebDriver driver = new ChromeDriver();
			 signup obj = new signup(driver);
			 
//			 Properties p = new Properties();
//			 FileReader fr = new FileReader(p);
		
		@Given("^I am on the homepage$")
		public void i_am_on_the_homepage() { 
	    obj.launch_app();
		System.out.println("home");
			
		}
//		  | first_name | last_name | phone_number | email                     | password       

		@When("^I click on the Account button$")
		public void i_click_on_the_account_button() throws InterruptedException {
			obj.selectAccount();
			Thread.sleep(2000);
		}

		@When("^I select the Signup option$")
		public void i_select_the_signup_option() throws InterruptedException {
			obj.selectSignup();
			Thread.sleep(1000);
		}

		@Then("^I should be redirected to the Signup page$")
		public void i_should_be_redirected_to_the_signup_page() {
			System.out.println("i am on signuppage ");
		}
	

		//validData
		@Given("^I am on the Signup page$")
		public void i_am_on_the_signup_page() {
			System.out.println("i am on signuppage 123");
		}

		@When("^I enter the first (.*) name$")
		public void i_enter_the_first_name(String first_name ) throws InterruptedException {
		 obj.enterFirstName(first_name);
		 Thread.sleep(2000);
		}
		  
		@And("^I enter the last (.*) name$")
		public void i_enter_the_last_name(String last_name) throws InterruptedException {
			obj.enterLastName(last_name);
			Thread.sleep(2000);
		}

		@When("^I select the country from the dropdown$")
		public void i_select_the_country_from_the_dropdown() throws InterruptedException {
		 obj.selectcounty();
		  Thread.sleep(2000);
		}

		@And("^I enter the phone (.*) number$")
		public void i_enter_the_phone_number(String phone_number) throws InterruptedException {
		obj.Enter_phoneNumber(phone_number);
			Thread.sleep(2000);
		}

		@When("^I enter the email (.*) address$")
		public void i_enter_the_email_address(String email) {
			obj.enter_email(email);
		}

		@When("^I enter the (.*) password$")
		public void i_enter_the_password(String password) {
		obj.Enter_password(password);
		}

		@When("^I click on the Signup button$")
		public void i_click_on_the_signup_button() {
			obj.submitpart();
		}

		@Then("^I should be redirected to the confirmation page with a success message")
		public void i_should_be_redirected_to_the_confirmation_page_with_a_success_message() {
			System.out.println("sucessful signuppage");
		}

	}




