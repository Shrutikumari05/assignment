//package com.pages;
//
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.IOException;
//import java.util.Properties;
//
//public class testreaddata {
//
//	public static void main(String[] args) throws IOException {
//		// TODO Auto-generated method stub
//		
//		Properties P = new Properties();
//		
//		FileReader fr = new FileReader("./testdata/input1.properties");
//		
//		P.load(fr);
//		
//		System.out.println(P.getProperty("username"));
//
//	}
//
//}
