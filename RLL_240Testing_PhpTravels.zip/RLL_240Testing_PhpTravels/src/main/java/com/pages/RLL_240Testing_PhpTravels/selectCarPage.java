package com.pages.RLL_240Testing_PhpTravels;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class selectCarPage {
	
	    WebDriver driver;
	 
		By cars = By.linkText("Cars");
		By book_now = By.xpath("(//button[@type='submit'])[2]");
		public void init(WebDriver driver)
		{
			this.driver = driver;
		}
		public void Launch_PHP_Travels() {
			driver.get("https://www.phptravels.net/");
			driver.manage().window().maximize();
		}
		public void second_link() throws InterruptedException {
			driver.findElement(cars).click();
			Thread.sleep(2000);
		}
		public void booknow() throws InterruptedException {
		    driver.manage().window().maximize();
		    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    boolean isVisible = false;
		    JavascriptExecutor js = (JavascriptExecutor) driver;
		    while (!isVisible) {
		        try {
		            WebElement bookNowButton = driver.findElement(book_now);
		            js.executeScript("arguments[0].scrollIntoView(true);", bookNowButton);
		            isVisible = bookNowButton.isDisplayed(); // Check if the button is displayed
		        } catch (Exception e) {
		            js.executeScript("window.scrollBy(0, 500);");
		            Thread.sleep(500); 
		        }
		    }
		    driver.findElement(book_now).click();
		}
	}

