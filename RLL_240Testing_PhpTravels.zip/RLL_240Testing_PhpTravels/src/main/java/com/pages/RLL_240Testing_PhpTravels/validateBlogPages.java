package com.pages.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class validateBlogPages {
WebDriver driver;
 
	
	By blog_url_link = By.xpath("(//a[@class=\"nav-link fadeout  waves-effect\"])[6]");
	By new_blog_list_blog3 = By.xpath("(//a[@class=\" waves-effect\"])[3]"); 
	By blog_title = By.xpath("//strong[contains(text(),\"The Tiber River’s Last Eel Fishermen\")]");
	By blog_image = By.xpath("//img[@class=\"w-100 rounded-2\"]");
	By blog_date = By.xpath("//div[@class=\"d-flex align-items-center justify-content-between\"]");
	By blog_content = By.xpath("//div[@class=\"card-body\"] ");
 
 
 
	public validateBlogPages(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
 
	public void LaunchPhpTravels()
	{
		driver.get("https://phptravels.net/");
		driver.manage().window().maximize();
	}
	public void clickblogs_url_link()
	{
		driver.findElement(blog_url_link).click();
	}
	public void clickblog_url_link()
	{
		driver.findElement(blog_url_link).click();
	}
	public void clicknew_blog_list_blog3()
	{
		driver.findElement(new_blog_list_blog3).click();
	}
	public void Vblog_title() {
	}
	public void Vblog_image() {
	}
	public void Vblog_date() {
	}
	public void Vblog_content()
	{
	}
}
