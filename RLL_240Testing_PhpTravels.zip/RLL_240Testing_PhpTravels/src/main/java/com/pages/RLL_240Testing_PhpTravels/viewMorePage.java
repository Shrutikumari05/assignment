package com.pages.RLL_240Testing_PhpTravels;
 
	import org.openqa.selenium.By;

	import org.openqa.selenium.JavascriptExecutor;

	import org.openqa.selenium.WebDriver;
	 
	public class viewMorePage { 

		WebDriver wd;

		By tours = By.linkText("Tours");


		By search1 = By.xpath("//button[contains(@class, 'search')]");

	    By viewMore1 = By.xpath("(//a[@class=\"fadeout py-2 d-flex align-items-center justify-content-center btn btn-primary rounded-1 d-block text-center waves-effect\"])[4]");


		public void init2(WebDriver wd) {

			this.wd = wd;

		}

		public void Launch_PHP_Travels1() {

			wd.get("https://www.phptravels.net/tours/Baku/baku/01-10-2024/1/0/");

			wd.manage().window().maximize();

			}



		public void search1() throws InterruptedException {

			wd.findElement(search1).click();

			Thread.sleep(3000);

		}



		public void viewMore1() throws InterruptedException  {

			wd.findElement(viewMore1).click();

		}
	 
}

	
	 

