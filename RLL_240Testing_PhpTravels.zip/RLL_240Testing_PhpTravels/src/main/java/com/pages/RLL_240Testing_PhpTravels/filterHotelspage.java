package com.pages.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class filterHotelspage {
	WebDriver wd;
	By Filter = By.linkText("Filter");

	
	By Price_Range = By.xpath("(//a[@class=\"btn d-flex justify-content-between align-items-center p-0 text-black waves-effect\"])[2]");

	By Price_Sort_By1 = By.id("desc");
	
	By Apply_Filters = By.xpath("//button[@class=\"btn btn-primary w-100 h-100 text-capitalize waves-effect\"]");
	By Reset = By.xpath("//div[@class=\"reset--btn\"]");
	
	By View_More = By.xpath("(//a[@class=\"w-100 fadeout py-2 d-flex align-items-center justify-content-center btn btn-primary d-block text-center waves-effect\"])[1]");
	
	
	
	
	
	public void intit(WebDriver wd) {
		this.wd=wd;
	}
	
	public void Launch_PHP_Travels() {
		wd.get("https://www.phptravels.net/hotls/dubai/07-10-2024/08-10-2024/1/2/0/IN");
		
		wd.manage().window().maximize();
	}
	

	
	public void Price_Range() {
		wd.findElement(Price_Range).click();
	}
	

	
	public void Price_Sort_By1() throws InterruptedException {
		wd.findElement(Price_Sort_By1).click();
		Thread.sleep(3000);
	}
	
	public void Apply_Filters() throws InterruptedException {
		wd.findElement(Apply_Filters).click();
		Thread.sleep(3000);
	}
	
	public void Reset() throws InterruptedException {
		wd.findElement(Reset).click();
		Thread.sleep(3000);
 
	}
	public void View_More() throws InterruptedException {
		wd.findElement(View_More).click();
		Thread.sleep(3000);
 
	}
	
	
 
}
 
