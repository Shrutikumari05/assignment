package com.pages.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class bookingPage {
	WebDriver driver;
	By Firstclass=By.xpath("//option[contains(text(),\"First\")]");
	By oneway_airlines=By.xpath("//input[@id=\"oneway_flights_2\"]");
	By Search=By.xpath("//button[@id=\"flights-search\"]");
	By select=By.xpath("//button[contains(text(),\"Select Flight\")]");
	By Firstname=By.xpath("(//input[@type=\"text\" and @class=\" form-control\"])[1]");
	By lastname=By.xpath("(//input[@type=\"text\" and @class=\" form-control\"])[2]");
	By email1=By.xpath("//input[@type=\"text\" and @placeholder=\"Email\"]");
	By phone=By.xpath("//input[@type=\"text\" and @placeholder=\"Phone\"]");
	By address1=By.xpath("//input[@type=\"text\" and @placeholder=\"Address\"]");
	By Nationality=By.xpath("(//button[@role=\"combobox\" and @type=\"button\"])[1]");
	By selectIndia=By.xpath("(//span[contains(text(),\"India\")])[2]");
	By currentCountry=By.xpath("(//button[@role=\"combobox\" and @type=\"button\"])[2]");
	By selectCountry=By.xpath("(//span[contains(text(),\"India\")])[4]");
	By Title=By.xpath("//select[@name='title_1']");
	By Titleclk=By.xpath("//*[@id=\"fadein\"]/main/div[2]/form/section/div/div/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/div[1]/div");



	By miss=By.xpath("//option[contains(text(),\"Miss\")]");
	By traveller_Fname=By.xpath("//input[@name=\"first_name_1\"]");
	By travleller_Lname=By.xpath("//input[@name=\"last_name_1\"]");
	By traveller_Nationality=By.xpath("//select[@name=\"nationality_1\"]");
	By select_traveller_nationality=By.xpath("(//option[contains(text(),\"India\")])[2]");
	By dob=By.xpath("//select[@name=\"dob_month_1\"]");
	By selectdob=By.xpath("//option[contains(text(),\"12 Dec\")][1]");
	By Traveller_day=By.xpath("//select[@name=\"dob_day_1\"]");
	By select_Traveller_day=By.xpath("(//option[contains(text(),\"14\")])[1]");
	By traveller_year=By.xpath("//select[@name=\"dob_year_1\"]");
	By select_traveller_year=By.xpath("(//option[contains(text(),\"1999\")])[1]");
	By passport=By.xpath("//input[@name=\"passport_1\"]");


	By pass_issu_yr=By.xpath("(//select[@class=\"form-select form-select\"])[6]");

	By pass_issu_clk=By.xpath("//*[@id=\"fadein\"]/main/div[2]/form/section/div/div/div[1]/div[2]/div[2]/div/div/div/div[2]/div[3]/div[2]/div/div[3]/div/select");



	By select_pass_issu_yr=By.xpath("(//option[contains(text(),\"2023\")])[2]");


	By payment_method=By.xpath("(//div[@id=\"pills-home-tab\"])[3]");
	By agree=By.xpath("//input[@id=\"agreechb\"]");
	By confirm_button=By.xpath("//button[@id=\"booking\"]");

	public bookingPage (WebDriver driver)
	{
		this.driver = driver;
	}

	public void Firstname(String firstname)  {

		driver.findElement(Firstname).sendKeys(firstname);


	}
	public void lastname(String fname) {
		driver.findElement(lastname).sendKeys(fname);
	}


	public void email(String email) {
		driver.findElement(email1).sendKeys(email);
	}
	public void phone(String phone2) {
		driver.findElement(phone).sendKeys(phone2);}


	public void address(String address) {
		driver.findElement(address1).sendKeys(address);}

	public void Nationality(String Nation_ality1) throws InterruptedException {
		driver.findElement(Nationality).click();
		Thread.sleep(300);
		driver.findElement(selectIndia).click();}


	public void currentCountry(String Current_Country) throws InterruptedException {
		driver.findElement(currentCountry).click();
		Thread.sleep(300);
		driver.findElement(selectCountry).click();}


	public void Title(String titl) throws InterruptedException {
		Thread.sleep(2000);
		
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)");


		driver.findElement(Titleclk).click();
		//Thread.sleep(3000);
		WebElement sel= driver.findElement(Title);
		Select selectTitle = new Select(sel);
	

		selectTitle.selectByVisibleText(titl);

	}




	public void Fname(String Fname) {

		driver.findElement(traveller_Fname).sendKeys(Fname);
	}



	public void Lname(String Lname) {
		driver.findElement(travleller_Lname).sendKeys(Lname);
	}

	public void traveller_Nationality() {
		driver.findElement(traveller_Nationality).click();
		driver.findElement(select_traveller_nationality).click();
	}

	public void dob() {
		driver.findElement(dob).click();
		driver.findElement(selectdob).click();}

	public void Traveller_day() {
		driver.findElement(Traveller_day).click();
		driver.findElement(select_Traveller_day).click();}

	public void traveller_year() throws InterruptedException {
		Thread.sleep(300);
		driver.findElement(traveller_year).click();
		driver.findElement(select_traveller_year).click();}

	public void passport(String pass) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		js.executeScript("window.scrollBy(0,500)");
		Thread.sleep(300);
		driver.findElement(passport).sendKeys(pass);}

	public void pass_issu_yr() throws InterruptedException {


		driver.findElement(pass_issu_clk).click();
		Thread.sleep(300);
		driver.findElement(select_pass_issu_yr).click();
		Thread.sleep(300);}



	public void payment_method() {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,850)");
		driver.findElement(payment_method).click();

	}

	public void booking_done() throws InterruptedException{

		Thread.sleep(500);
		driver.findElement(agree).click();
	}
	public void confirm_button() throws InterruptedException {
		Thread.sleep(500);
		driver.findElement(confirm_button).click();

	}
}


