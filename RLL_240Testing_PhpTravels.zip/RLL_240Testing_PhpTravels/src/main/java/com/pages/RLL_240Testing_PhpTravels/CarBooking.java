package com.pages.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CarBooking {
	WebDriver wd;
	By cars = By.xpath("//span[contains(text(),'Cars')]");
	By book_now = By.xpath("(//button[@type='submit'])[2]");
	By FirstName = By.xpath("//input[contains(@name, 'user[first_name]')]");
	By Last_Name = By.xpath("//input[@name=\"user[last_name]\"]");
	By emailField = By.xpath("//input[@name=\"user[email]\"]");
	By phoneField = By.xpath("//input[@name=\"user[phone]\"]");
	By Address= By.xpath("//*[@ placeholder=\"Address\"]");

	By nationalityDropdown = By.xpath("//*[@class=\"btn dropdown-toggle btn-light\"]");
	By search_field = By.xpath("(//input[@class=\"form-control\" and @type=\"search\"])[1]");
	By india = By.xpath("(//span[@class=\"text-dark\"])[3]");

	By currentCountry = By.xpath("(//button[@class=\"btn dropdown-toggle btn-light\"])[2]");
	By search_field2 = By.xpath("(//input[@class=\"form-control\" and @type=\"search\"])[2]");
	By india1 = By.xpath("(//span[contains(text(),\"India\")])[5]");

	By title1 = By.xpath("//select[@name=\"title_1\"]");
	By firstName1= By.xpath("//input[@name=\"firstname_1\"]");
	By lastName1 = By.xpath("//input[@name=\"lastname_1\"]");
	By title2 = By.xpath("(//*[@class=\"form-select\"])[2]");
	By firstName2 = By.xpath("//input[@name=\"firstname_2\"]");
	By lastName2 = By.xpath("//input[@name=\"lastname_2\"]");
	By pay_later = By.xpath("//input[@id=\"gateway_pay_later\"]");
	By i_agree = By.id("agreechb");
	By booking_confirm = By.xpath("//button[contains(text(),\" Booking Confirm\")]");
	
	public CarBooking (WebDriver wd)
	{
		this.wd = wd;
	}	
	public void cars() {
		wd.findElement(cars).click();
	}
	public void book_now() throws InterruptedException {
		wd.findElement(book_now).click();
		Thread.sleep(2000);
	}
	

public void firstName(String first_name) {
		wd.findElement(FirstName).sendKeys(first_name);
	}

	public void Last_Name(String last_name) {
		wd.findElement(Last_Name).sendKeys(last_name);
	}

	public void emailField(String email ) {
		wd.findElement(emailField).sendKeys(email );
	}

	public void phoneField(String phone) {
		wd.findElement(phoneField).sendKeys(phone);
	}

	public void Address(String  address) {
		wd.findElement(Address).sendKeys( address);
	}

	public void nationalityDropdown(String nationality) throws InterruptedException {
		wd.findElement(nationalityDropdown).click();
		wd.findElement(search_field).sendKeys(nationality);
		wd.findElement(search_field).sendKeys(Keys.ARROW_DOWN);
		wd.findElement(india).click();
		Thread.sleep(2000);

	}

	public void currentCountry(String current_country) throws InterruptedException {
		wd.findElement(currentCountry).click();
		wd.findElement(search_field2).sendKeys(current_country);
		wd.findElement(search_field2).sendKeys(Keys.ARROW_DOWN);
		wd.findElement(india1).click();
		Thread.sleep(2000);

	}

	public void title1(String title) {
		wd.findElement(title1).sendKeys(title);
	}

	public void firstName1(String traveller_first_name) {
		wd.findElement(firstName1).sendKeys(traveller_first_name);
	}

	public void lastName1(String traveller_last_name) {
		wd.findElement(lastName1).sendKeys(traveller_last_name);
	}

	public void title2(String title_2) {
		wd.findElement(title2).sendKeys(title_2);
	}

	public void firstName2(String traveller_first_name_2) {
		wd.findElement(firstName2).sendKeys(traveller_first_name_2);
	}
	public void lastName2(String traveller_last_name_2) {
		wd.findElement(lastName2).sendKeys(traveller_last_name_2);
		
		
		
		WebElement payLaterElement = wd.findElement(By.xpath("//input[@id=\"gateway_pay_later\"]"));
		((JavascriptExecutor) wd).executeScript("arguments[0].scrollIntoView(true);", payLaterElement);
	}
	public void booknow() throws InterruptedException {
		wd.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor) wd;
		js.executeScript("window.scrollBy(0,650)");
		
	}
	public void pay_later(String payment_method) throws InterruptedException {

		wd.findElement(pay_later).click();
		Thread.sleep(1000);
	}
	public void i_agree() {
		wd.findElement(i_agree).click();
	}
	public void booking_confirm() {
		wd.findElement(booking_confirm).click();
		wd.close();
	}


}

