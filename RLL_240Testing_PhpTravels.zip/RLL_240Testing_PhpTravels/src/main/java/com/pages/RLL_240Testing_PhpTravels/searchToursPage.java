package com.pages.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class searchToursPage {
	    WebDriver wd;
		By find_Best_Tours = By.xpath("//*[contains(text(),\"Find Best Tours\")]");
		By tours = By.linkText("Tours");
		By search_by_city = By.xpath("//span[contains(text(),\" Search by City \")]");
		//By search_city = By.xpath("//*[contains(text(),'Azerbaijan')]");
		By search_city = By.xpath("//input[@class=\"select2-search__field\" and @type=\"search\"]");
		By calender = By.id("date");
	    By date = By.xpath("//td[text()=\"1\"]");
	    By travelers = By.xpath("//a[@class=\"dropdown-toggle dropdown-btn travellers waves-effect\"]");
		By adults_plus = By.xpath("(//*[name()='svg'])[8]");
		By adults_minus = By.xpath("(//*[name()='svg'])[9]");
		By childs_plus = By.xpath("(//*[name()='svg'])[11]");
		By childs_minus = By.xpath("(//*[name()='svg'])[10]");
		By search = By.xpath("//button[contains(@class, 'search')]");
	    By viewMore = By.xpath("(//a[@class=\"fadeout py-2 d-flex align-items-center justify-content-center btn btn-primary rounded-1 d-block text-center waves-effect\"])[4]");

		public void init1(WebDriver wd) {
			this.wd = wd;
		}
		public void Launch_PHP_Travels() {
			wd.get("https://www.phptravels.net/");
			wd.manage().window().maximize();
			}
		public void second_link() {
			wd.findElement(tours).click();
		}
		public void Find_best_tours() {
			wd.findElement(find_Best_Tours).click();
		}
		public void search_by_city(String city) throws InterruptedException {
	        wd.findElement(search_by_city).click();
	        wd.findElement(search_city).sendKeys(city);
			Thread.sleep(500);
			wd.findElement(search_city).sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(500);
			wd.findElement(search_city).sendKeys(Keys.ENTER);
			Thread.sleep(1000);
	    }
		public void search_city() {
			wd.findElement(search_city).click();
		}
		public void calender() {
			wd.findElement(calender).click();
		}
		public void date() {
			wd.findElement(date).click();
		}
		public void travelers() {
			wd.findElement(travelers).click();
		}
		public void adults_plus() {
			wd.findElement(adults_plus).click();
		}
		public void adults_minus() {
			wd.findElement(adults_minus).click();
		}
		public void childs_plus() {
			wd.findElement(childs_plus).click();
		}
		public void childs_minus() {
			wd.findElement(childs_minus).click();
		}
		public void search() throws InterruptedException {
			wd.findElement(search).click();
			Thread.sleep(3000);

		}
		/*public void image() {
			wd.findElement(image).click();
		}*/
		public void viewMore() {
			wd.findElement(viewMore).click();
		}
	}

