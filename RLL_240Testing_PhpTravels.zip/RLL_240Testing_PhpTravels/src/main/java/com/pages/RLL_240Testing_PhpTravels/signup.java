package com.pages.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class signup {

	WebDriver driver;
	By Account = By.xpath("//strong[contains(text(),\"Account\")]");
	By signup=By.xpath("//strong[contains(text(),\"Signup\")]");
	By firstname=By.xpath("//input[@id=\"firstname\"]");
	
	By lastname=By.xpath("//input[@id=\"last_name\"]");
	By select_country=By.xpath("//select[@name=\"phone_country_code\"]");
	By phone_no=By.xpath("//input[@id=\"phone\"]");
	By user_email=By.xpath("//input[@id=\"user_email\"]");
	By user_password=By.xpath("//input[@id=\"password\"]");
	By	checkbox=By.xpath("//span[@id=\"recaptcha-anchor\"]");
	By	button=By.xpath("//button[@id=\"submitBTN\"]");

	By countyname=By.xpath("//span[contains(text(),\"Algeria \")]");

	public signup(WebDriver driver) {
		this.driver=driver;
	}

	public void  launch_app() {
		driver.get("https://phptravels.net/");
		driver.manage().window().maximize();
		
	}
	
	public void selectAccount() {

		driver.findElement(Account).click();
		
	}
	
	public void selectSignup()  {
		
		driver.findElement(signup).click();	
	}

	public void enterFirstName(String first_name )  {
		driver.findElement(firstname).sendKeys(first_name);
	
	}

	public void enterLastName(String last_name){
		driver.findElement(lastname).sendKeys(last_name);

	}
 
	public void selectcounty()  {
	
		driver.findElement(select_country).click();
		
		driver.findElement(countyname).click();
	}

	public void Enter_phoneNumber(String phone_number ) {  
	
		driver.findElement(phone_no).sendKeys(phone_number);
	}
	
	public void enter_email(String email) {
	
		driver.findElement(user_email).sendKeys(email);
	}

	public void Enter_password(String password) {
		
		driver.findElement(user_password).sendKeys(password);      
	}

	public void clickcheckbox() throws InterruptedException {
		Thread.sleep(25000);
		driver.findElement(checkbox).click(); 
	}

	public void submitpart()
	{
		driver.findElement(button).click(); 
	}
}
