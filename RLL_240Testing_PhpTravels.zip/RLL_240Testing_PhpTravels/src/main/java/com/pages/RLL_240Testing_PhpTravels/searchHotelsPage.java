package com.pages.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class searchHotelsPage {
	WebDriver wd;
    By Hotels = By.xpath(null);
    By Search_for_best_hotels = By.xpath("(//a[@class=\"nav-link fadeout  waves-effect\"])[1]");
    By Search_By_City = By.xpath("//span[@class=\"select2-selection__rendered\"]");
    By search_city = By.xpath("(//*[contains(text(),'Dubai')])[2]");
    By Checkin_calender = By.id("checkin");
    By Checkin_Date = By.xpath("(//td[text()='7'])[1]");
    By Checkout_Calender = By.id("checkout");
    By Checkout_Date = By.xpath("(//td[contains(text(),'15')])[2]");
    By Travellers = By.xpath("//a[@class='dropdown-toggle dropdown-btn travellers d-flex align-items-center waves-effect']");
    By Search = By.xpath("//button[contains(@class, 'search_button')]");
 
    public void init(WebDriver wd) {
        this.wd = wd;
    }
 
    public void Launch_PHP_Travels() {
        wd.get("https://www.phptravels.net/");
        wd.manage().window().maximize();
    }
 
    public void second_link() {
        wd.findElement(Hotels).click();
    }
 
    public void Search_for_best_hotels() throws InterruptedException {
        wd.findElement(Search_for_best_hotels).click();
        wd.findElement(Search_By_City).sendKeys();
        Thread.sleep(1000);    
		wd.findElement(search_city).sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(1000);
		wd.findElement(search_city).sendKeys(Keys.ENTER);
		Thread.sleep(1000);
 
    }
 
//    public void Search_By_City() {
//        wd.findElement(Search_By_City).click();
//    }
 
//    public void search_city(String fromSearch_By_City) throws InterruptedException {
//        wd.findElement(search_city).click();
//        wd.findElement(search_city).sendKeys(fromSearch_By_City);
//        Thread.sleep(2000);
//		wd.findElement(Search_By_City).sendKeys(Keys.ARROW_DOWN);
//		Thread.sleep(500);
//		wd.findElement(Search_By_City).sendKeys(Keys.ENTER);
//		Thread.sleep(1000);
//
//    }
 
    public void Checkin_calender() {
        wd.findElement(Checkin_calender).click();
    }
 
    public void Checkin_Date() {
        wd.findElement(Checkin_Date).click();
    }
 
    public void Checkout_calender() {
        wd.findElement(Checkout_Calender).click();
    }
 
    public void Checkout_Date() {
        wd.findElement(Checkout_Date).click();
    }
 
    public void Travellers() {
        wd.findElement(Travellers).click();
    }
 
    public void Search() {
        wd.findElement(Search).click();
    }
 
	public void Search_By_City() {
		// TODO Auto-generated method stub
		
	}
}
 

