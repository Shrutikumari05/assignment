package com.pages.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class filterPage {
	public filterPage(WebDriver driver) {
	
			this.driver = driver;
		}
		WebDriver driver;
		By Flight_class=By.xpath("//select[@id=\"flight_type\"]");
	    By Economy=By.xpath("//option[contains(text(),\"Economy\")]");

	    
	    By allflights = By.id("all");
	    By hightolow = By.xpath("(//span[@class=\"d-block w-100 d-flex align-items-center justify-content-center gap-2\"])[2]");
	 
	    By selectingflight = By.xpath("(//button[contains(text(), 'Select Flight')])[1]");
	    
	    public void navigate()
	    {
	    	
	    }
	    public void selectingdirect() throws InterruptedException
		 {
	    	
	    	driver.manage().window().maximize();
	    	Thread.sleep(2000);
			 driver.findElement(allflights).click();
		 }
		 public void selectinghightolow() throws InterruptedException
		 {
			 Thread.sleep(2000);
			 driver.findElement(hightolow).click();
		 }
		 public void selectingflight() throws InterruptedException
		 {
			 Thread.sleep(2000);
			 driver.findElement(selectingflight).click();
		 }

	}


