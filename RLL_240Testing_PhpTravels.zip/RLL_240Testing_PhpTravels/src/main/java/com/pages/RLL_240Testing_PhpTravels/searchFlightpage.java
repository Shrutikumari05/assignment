package com.pages.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class searchFlightpage {
	WebDriver driver;
	By oneway=By.xpath("//small[text()='One Way']");
	By dropdown1=By.xpath("(//b[@role=\"presentation\"])[1]");
	By germany=By.xpath("(//small[text()=\"Germany\"])[2]");
	By dropdown2=By.xpath("(//b[@role=\"presentation\"])[2]");
	By Delhi=By.xpath("//small[text()=\"India\"]");
	By calendar=By.xpath("//input[@id=\"departure\"]");
	By Date=By.xpath("(//td[contains(text(),\"10\")])[1]");
    By  traveclk = By.xpath("//*[@id='onereturn']/div[4]/div");
    By  child = By.id("fchilds");
    By Search=By.xpath("//button[@id=\"flights-search\"]"); 
    By Flight_class=By.xpath("//select[@id=\"flight_type\"]");
    By Economy=By.xpath("//option[contains(text(),\"Economy\")]");
    //By stop=By.xpath("//input[@id=\"direct\"]");
    By allflights = By.xpath("//input[@id=\"all\"]");
    By hightolow = By.xpath("(//span[@class=\"d-block w-100 d-flex align-items-center justify-content-center gap-2\"])[2]");
 
    By selectingflight = By.xpath("(//button[contains(text(), 'Select Flight')])[1]");
	public searchFlightpage (WebDriver driver) {
		this.driver = driver;
	}
	
    public void onway() throws InterruptedException {

		Thread.sleep(3000);
		
	}
    
    
    
   	public void Flying() throws InterruptedException {
   		driver.findElement(dropdown1).click();
   		driver.findElement(germany).click();
   		Thread.sleep(2000);
   	
   		}
   	
   	public void i_select_the_first_box( String FromCountry) throws InterruptedException {

   		driver.manage().window().maximize();
   		Thread.sleep(2000);

   		driver.findElement(By.xpath("//span[@title='Select City'][1]")).click();

   		Thread.sleep(2000);


   		driver.findElement(By.xpath("//*[@id=\"fadein\"]/span/span/span[1]/input")).sendKeys(FromCountry);
   		Thread.sleep(2000);

   		driver.findElement(By.xpath("//ul[@class='select2-results__options']/li[1]")).click();
   	



   	}

   	public void i_select_the_second_box(String Tocountry) throws InterruptedException {

   		Thread.sleep(2000);
   		driver.findElement(By.xpath("//*[@id=\"onereturn\"]/div[2]/div[2]")).click();
   		Thread.sleep(2000);
   		//*[@id="fadein"]/span/span/span[1]/input
   		driver.findElement(By.xpath("//*[@id=\"fadein\"]/span/span/span[1]/input")).sendKeys(Tocountry);
   		Thread.sleep(2000);

   		//driver.findElement(By.xpath("//ul[@class='select2-results__options']/li[1]")).click();
   		driver.findElement(By.xpath("//ul[@class='select2-results__options']/li[1]")).click();
   		Thread.sleep(2000);
   		driver.findElement(By.cssSelector("input[class=\"depart form-control\"]")).click();
   		Thread.sleep(4000);
   		driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[5]/div[1]/table/thead/tr[1]/th[2]")).click();
   		Thread.sleep(2000);

   		
   	}


    public void travelselect() throws InterruptedException {
   		Thread.sleep(2000);
   		driver.findElement(By.xpath("//*[@id=\"onereturn\"]/div[4]/div")).click();
   	
   		driver.findElement(By.id("fadults")).clear();
   		driver.findElement(By.id("fadults")).sendKeys("1");
   		
   		Thread.sleep(2000);
   		WebElement enter= driver.findElement(By.cssSelector("input[id=\"finfant\"]"));

   		// Initialize Actions class
   		Actions actions = new Actions(driver);

   		// Move to the second element and perform down arrow key press followed by enter
   		actions.moveToElement(enter).sendKeys(Keys.ENTER).perform();

   	
    }
   	
   	 public void destination() throws InterruptedException {
   		
   		
         driver.findElement(dropdown2).click();
   		driver.findElement(Delhi).click();	
   		Thread.sleep(2000);
   		
   }
   	 public void date() throws InterruptedException {
   		
   		driver.findElement(calendar).click();
   		driver.findElement(Date).click();
   		Thread.sleep(2000);
   	}
   	 public void traveller() throws InterruptedException
   	 {
   		
   	 }
   	 public void search() throws InterruptedException
   	 {
   		 Thread.sleep(2000);
   		 driver.findElement(Search).click();
   	 }
   
   	 

   }

