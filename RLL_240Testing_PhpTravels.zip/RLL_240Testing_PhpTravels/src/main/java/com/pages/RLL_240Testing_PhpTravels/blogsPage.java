package com.pages.RLL_240Testing_PhpTravels;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.google.common.io.Files;

public class blogsPage {
	  WebDriver wd;

	    // Locators
	    By blog_url = By.xpath("//a[contains(text(),'Blogs')]");
	    By validate_phptravles = By.xpath("//h2[contains(text(),\"PHPTRAVELS\")]") ;
	    By view_more_button = By.id("loadMore"); // Fixed locator
	    By arrow_to_open_blog1 = By.xpath("(//span[@class='share--post d-flex justify-content-center align-items-center'])[8]");

	  
	    public blogsPage(WebDriver driver) {
	        this.wd = driver;
	    }
	    public void launch() throws IOException {
	    	wd.get("https://phptravels.net/");
	    	wd.manage().window().maximize();
	    	File src=((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
		    Files.copy(src, new File("./Screenshots/shot1.png"));
		
	    }

	   
	    public void clickBlogUrl() throws InterruptedException {
	        wd.findElement(blog_url).click();
	        Thread.sleep(2000);
	    }
	    
	    // Click on the View More button
	    public void clickViewMoreButton() throws InterruptedException {
	    	
	    	 WebElement viewMoreButton = wd.findElement(view_more_button);
	    	    
	    	    // Scroll until the element is in view
	    	    ((JavascriptExecutor) wd).executeScript("arguments[0].scrollIntoView(true);", viewMoreButton);
	    	    Thread.sleep(2000);
	    	   
	    	    viewMoreButton.click();	    
	     
	    }

	    // Click on the arrow to open the first blog
	    public void clickArrowToOpenBlog1() throws InterruptedException {
	    	 Thread.sleep(2000);
	        wd.findElement(arrow_to_open_blog1).click();
	        
	    }

	    
	}


