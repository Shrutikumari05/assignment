package com.runner.RLL_240Testing_PhpTravels;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/test/resource/com/features",
glue="com.stepdefinition.RLL_240Testing_PhpTravels",
tags="@hotelSearch",// or @verifyblog or @Positive" or @filterhotel,
monochrome=true)
public class RunnerTestNG extends AbstractTestNGCucumberTests{

}
