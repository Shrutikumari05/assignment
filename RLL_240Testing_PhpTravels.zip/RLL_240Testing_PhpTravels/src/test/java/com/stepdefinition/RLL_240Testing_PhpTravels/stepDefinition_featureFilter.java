package com.stepdefinition.RLL_240Testing_PhpTravels;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_PhpTravels.featuredFlightPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition_featureFilter {
	 // To manage WebDriver
	
    private featuredFlightPage obj;
    WebDriver wd;
    Logger log;
  
    
   public stepDefinition_featureFilter(){
	   
   wd= new ChromeDriver();
   obj = new featuredFlightPage(wd);
   log=Logger.getLogger(stepDefinition_featureFilter.class);
   }
   
	   
	@Given("I am on homepage of PHP Travels homepage")
   public void I_am_on_homepage_of_PHP_Travels_homepage() throws IOException {
	obj.Launch_app();
	
 
	log.info("pass");
	
}
 
 
@When("I should see Featured Flight section")
public void I_should_see_Featured_Flight_section() {
	
	System.out.println("Wel-Come");
}
 

@When("I press the down key")
public void I_press_the_down_key() {
	obj.arrow_down();
}
 

 
@When("I select the first flight displayed")
public void I_select_the_first_flight_displayed() {
	obj.select_lahor();
}
 
 
@Then("I see flight details page")
public void I_see_flight_details_page() {
	System.out.println("This is list of Featured_Flights");
}
 
}

 

