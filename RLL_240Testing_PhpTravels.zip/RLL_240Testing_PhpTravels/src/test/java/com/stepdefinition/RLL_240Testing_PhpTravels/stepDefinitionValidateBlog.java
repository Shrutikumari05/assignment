package com.stepdefinition.RLL_240Testing_PhpTravels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.pages.RLL_240Testing_PhpTravels.validateBlogPages;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinitionValidateBlog {
	By blog_title = By.xpath("//strong[contains(text(),\"The Tiber River’s Last Eel Fishermen\")]");
	By blog_image = By.xpath("//img[@class=\"w-100 rounded-2\"]");
	By blog_date = By.xpath("//div[@class=\"d-flex align-items-center justify-content-between\"]");
	By blog_content = By.xpath("//div[@class=\"card-body\"] ");
	
	WebDriver driver;
	
	// Ensure you have the appropriate WebDriver setup
	validateBlogPages blogPage = new validateBlogPages(driver);
 
	@Given("I launch the PHPTravels website")
	public void i_launch_the_PHPTravels_website() throws InterruptedException {
		driver= new ChromeDriver();
		blogPage.LaunchPhpTravels();
		Thread.sleep(1000);
	}
 
	@When("I click on the Blogs link")
	public void i_click_on_the_blogs_link() {
		blogPage.clickblogs_url_link();
	}
 
	@When("I click on the third blog in the list")
	public void i_click_on_the_third_blog_in_the_list() {
		blogPage.clicknew_blog_list_blog3();
	}
	
	@Then("I should see the blog title")
	public void i_should_see_the_blog_title() {
		WebElement exp = driver.findElement(By.xpath("//strong[contains(text(),\"The Tiber River’s Last Eel Fishermen\")]"));
		Assert.assertEquals(exp, "The Tiber River’s Last Eel Fishermen","Title");
	}
 
	@Then("I should see the blog image")
	public void i_should_see_the_blog_image() {
//		WebElement exp1 = driver.findElement(By.xpath("//img[@class=\\"w-100 rounded-2\\"]"));
	//	Assert.assertEquals(exp1, "The Tiber River’s Last Eel Fishermen","Title");
}

	@Then("I should see the blog date")
	public void i_should_see_the_blog_date() {
		WebElement exp2 = driver.findElement(By.xpath("//div[@class=\"d-flex align-items-center justify-content-between\"]"));

		Assert.assertEquals(exp2, "17-7-23","date");
	}

	@Then("I should see the blog content")
	public void i_should_see_the_blog_content() {
		WebElement exp3 = driver.findElement(By.xpath("//div[@class=\\\"card-body\\\"]"));

		Assert.assertEquals(exp3, "Content","Content");
	}


}
