package com.stepdefinition.RLL_240Testing_PhpTravels;



import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

//import com.hooks_phpTravels.Hooks;
import com.pages.RLL_240Testing_PhpTravels.CarBooking;
import com.pages.RLL_240Testing_PhpTravels.selectCarPage;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition_selectAndBookCar {
	   WebDriver driver;
	   Logger log ;
	   selectCarPage lib = new selectCarPage ();
	   CarBooking  info = new CarBooking (driver);
	   @Before
		public void setup()
		{
			driver = new ChromeDriver();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		}
		
		@Given("The user is on PHP travels")
		public void The_user_is_on_PHP_travels() throws InterruptedException {	
			lib.init(driver);
			lib.Launch_PHP_Travels();
			lib.second_link();
			log.info("passed");
		}
		@When("user clicks on cars")
		public void user_clicks_on_cars() throws InterruptedException {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	 
		}
	 
		@And("user clicks on Book Now button for Hyundai i10")
		public void user_clicks_on_Book_Now_button_for_Hyundai_i10() throws InterruptedException {
			lib.booknow();
			info.cars();
			
		}
		
		@And("^Enter the First name (.*)$")
		public void Enter_the_First_name(String first_name) {
			info.firstName(first_name);
		}
	 
		@And("^Enter the Last name(.*)$")
		public void enter_the_Last_name(String last_name) {
			info.Last_Name(last_name);
		}
	 
		@And("^Enter the email id(.*)$")
		public void enter_the_email_id(String email) {
			info.emailField(email);
		}
	 
		@And("^Enter the phone number(.*)$")
		public void enter_the_phone_number(String phone) {
			info.phoneField(phone);
		}
	 
		@And("^Enter the address(.*)$")
		public void enter_the_address(String address) {
			info.Address(address);
		}
	 
		@And("^Select the nationality as(.*)$")
		public void select_the_nationality_as(String nationality) throws InterruptedException {
			info.nationalityDropdown(nationality);
		}
	 
		@And("^Select the current country as(.*)$")
		public void select_the_current_country_as(String current_country) throws InterruptedException {
			info.currentCountry(current_country);
		}
	 
		@And("^Select the title1 as(.*)$")
		public void select_the_title_as(String title) {
			info.title1(title);
		}
	 
		@And("^Enter the first_name1(.*)$")
		public void enter_the_first_name1(String traveller_first_name) {
			info.firstName1(traveller_first_name);
		}
	 
		@And("^Enter the last_name1(.*)$")
		public void enter_the_last_name1(String traveller_last_name) {
			info.lastName1(traveller_last_name);
		}
	 
		@And("^Select the title2 as (.*)$")
		public void select_the_title_as_2(String title_2) {
			info.title2(title_2);
		}
	 
		@And("^Enter the first_name2 (.*)$")
		public void enter_the_first_name2(String traveller_first_name_2) {
			info.firstName2(traveller_first_name_2);
		}
	 
		@And("^Enter the last_name2 (.*)$")
		public void enter_the_last_name2(String traveller_last_name_2) {
			info.lastName2(traveller_last_name_2);
		}
	 
		@And("^Select the payment method as (.*)$")
		public void select_the_payment_method_as(String payment_method) throws InterruptedException {
			info.pay_later(payment_method);
		}
	 
		@And("Click on the booking confirm button")
		public void click_on_the_booking_confirm_button() {
			info.i_agree();
		}
	 
		@Then("Should get the booking confirmation details")
		public void should_get_the_booking_confirmation_details() {
			info.booking_confirm();
			String expectedConfirmationDetails = "Expected Details"; // Replace with the actual expected details
			Assert.assertEquals("Booking confirmation details should match", expectedConfirmationDetails,expectedConfirmationDetails);
		}
	
	   
}
	   