package com.stepdefinition.RLL_240Testing_PhpTravels;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.pages.RLL_240Testing_PhpTravels.filterHotelspage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinitionFilterHotels {
	WebDriver driver;
	filterHotelspage filterHotels;
    Logger log2;
 
    @Given("the user is on the PHP Travels hotels page")
    public void the_user_is_on_the_php_travels_hotels_page() {
        driver = new ChromeDriver();
        filterHotels = new filterHotelspage();
        filterHotels.intit(driver);
        filterHotels.Launch_PHP_Travels();
        log2 = Logger.getLogger(stepDefinitionFilterHotels.class);
        
    }
 
    @When("the user clicks on Star Rating")
    public void the_user_clicks_on_star_rating() {
        filterHotels.Price_Range();
    }
 
    @When("clicks on Price Range")
    public void clicks_on_price_range() {
        filterHotels.Price_Range();
    }
 
    @When("clicks on Price Sort by")
    public void clicks_on_price_sort_by() throws InterruptedException {
        filterHotels.Price_Sort_By1();
    }
    @Then("the user should see hotel details by valid filters")
    public void the_user_should_see_hotel_details_by_valid_filters() throws InterruptedException {
        filterHotels.Apply_Filters();
        // Add logic to verify if hotels are filtered correctly
        boolean isFiltered = true; // Replace with actual verification logic
        Assert.assertTrue(isFiltered);
       //driver.quit();
    }
}
