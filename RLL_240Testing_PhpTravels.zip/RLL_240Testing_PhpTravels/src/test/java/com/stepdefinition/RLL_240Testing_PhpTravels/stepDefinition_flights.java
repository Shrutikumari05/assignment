package com.stepdefinition.RLL_240Testing_PhpTravels;

import com.hooks_phpTravels.Hooks;

import com.pages.RLL_240Testing_PhpTravels.searchFlightpage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition_flights {
	searchFlightpage  homepage = new searchFlightpage (Hooks.driver);

    

    @Given("I open the browser and navigate to the flight booking page")
    public void i_open_the_browser_and_navigate_to_the_flight_booking_page() {
       // driver = new EdgeDriver();
      //  homepage = new Rll_homepage(driver);
//    	log1=Logger.getLogger(StepDefinitions.class);
    	
       
    }

    @When("I select one way trip")
    public void i_select_one_way_trip() throws InterruptedException {
        homepage.onway();
//        log1.info("user select on way trip");
    }
    //"^Field enter (.*) and (.*)$"
    @When("^I choose (.*) as the departure country$")
    public void i_choose_Fromcountry_as_the_departure_country(String Fromcountry) throws InterruptedException {
      //  homepage.Flying();
        homepage.i_select_the_first_box(Fromcountry);
        Thread.sleep(2000);
    }
    
    @Then("I validate the results")
    public void i_validate_the_results() {
        // Write code here that turns the phrase above into concrete actions
      //  throw new io.cucumber.java.PendingException();
    }

    @When("^I choose (.*) as the destination country$")
    public void i_choose_Tocountry_as_the_destination_country(String Tocountry) throws InterruptedException {
       // homepage.destination();
        homepage.i_select_the_second_box(Tocountry);
        
    }

    @When("I select the departure date")
    public void i_select_the_departure_date() throws InterruptedException {
        homepage.date();
    }

    @When("I select the number of travelers")
    public void i_select_the_number_of_travelers() throws InterruptedException {
        homepage.traveller();
    }

    @Then("I click on the search button")
    public void i_click_on_the_search_button() throws InterruptedException {
        homepage.search();
    }
    
}


