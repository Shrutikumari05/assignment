package com.stepdefinition.RLL_240Testing_PhpTravels;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_PhpTravels.featuredflightfilter;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinitionFeaturedFlight {
	WebDriver wd ;
	featuredflightfilter obj;
	
	    
	    public stepDefinitionFeaturedFlight() {
	    	wd = new ChromeDriver();
	    	obj=new featuredflightfilter(wd);
	        
	    }
	
	@Given("^on the Featured flight search$")
	public void on_the_Featured_flight_search() throws IOException {
		System.out.println("welcome");
	    obj.launchapp();
		obj.navigate_filterflight();
	}
    
	
	
	
	
	@And("^I select one way trip$")
	public void I_select_one_way_trip() throws InterruptedException {
		obj.onway();
	}
	
	
	
	
    @When("^I should enters (.*) and (.*)$")
	public void I_enter_Flying_and_Destination_field(String Flying,String Destination_field ) throws InterruptedException{
    	obj.Flying();
    	obj.destination();
    }
	
	
    @And("^I enter (.*) and select one Traveller$")
   public void I_enter_Departure_date_and_select_one_Traveller(String Departure_date ) throws InterruptedException{
    	obj.date();
    }
	
	
    @And("^I adjust the price range as needed$")
    public void I_adjust_the_price_range_as_needed() {
    	System.out.println("I_adjust_the_price_range_as_needed");
    	
    }
	
    @And("^I select flight stops as Direct and choose Flydubai$")
    public void I_select_flight_stops_as_Direct_and_choose_Flydubai(){
    	System.out.println("I_select_flight_stops_as_Direct_and_choose_Flydubai");
    }
	
    @And("^I select (.*) can use as per requirement$")
    public void I_select_Flight_class_can_use_as_per_requirement(String Flight_class) throws InterruptedException {
    	obj.Flight_class();
    }
	
	
    @And("^I choose the first flight displayed$")
    public void I_choose_the_first_flight_displayed() {
    	System.out.println("I choose the first flight displayed");
    }
	
    @Then("^I should see the Booking Flight page with the relevant flights$")
    public void I_should_see_the_Booking_Flight_page_with_the_relevant_flights() {
    	System.out.println("I should see the Booking Flight page with the relevant flights");
    }
    
    
	//booking
    @Given("^User is on Booking page of PHP Travels$")
    public void User_is_on_Booking_page_of_PHP_Travels() {
    	
    	System.out.println("Wel-come");
    	
    	
    }
    	
    
   @When("^Field enter (.*) and (.*)$")
    public void User_enter_Firstname_and_Lastname(String Firstname,String Lastname) throws InterruptedException {
    	
    	String expectedTitle="Flights Booking";
		String actualTitle=wd.getTitle();
		assertEquals(expectedTitle, actualTitle);
		obj.Firstname();
    	obj.lastname();
    }
    
    
    @And("^User enter (.*) and (.*) in field$")
    public void User_enter_Email_and_Phone_in_field(String Email,String Phone) throws InterruptedException {
    	obj.email();
    	obj.phone();
    	
    	
    }
    
    
    @And("^User should enter (.*)$")
    public void User_enter_Address(String Address) throws InterruptedException {
    	obj.address();
    	
    }
    
    @And("^Do enter (.*) and (.*) on$")
    public void User_enter_Nation_ality1_and_Current_Country(String Nation_ality1,String Current_Country ) throws InterruptedException {
    	
    	obj.Nationality();
    	obj.currentCountry();
    }
    
    @And("^User enter (.*) from dropdowns$")
    public void User_enter_Title_from_dropdowns(String Title) throws InterruptedException {
    	
    	obj.Title();
    	
    }
    
    @And("^User entered information as (.*) and (.*).$")
    public void User_entered_information_as_Traveller_F_and_Traveller_L(String Traveller_F,String Traveller_L) throws InterruptedException {
    	
    	
    	obj.Fname();
    	obj.Lname();
    }
    
    @And("^enters (.*) and (.*)$")
    public void User_enter_Nationality_and_Date_of_birth(String Nationality,String Date_of_birth) throws InterruptedException {
    	obj.traveller_Nationality();
    	obj.dob();
    	
    }
    
    @And("^enter (.*) and (.*) From DropDown..$")
    public void enter_BirthDay_and_birth_Year_From_DropDown(String BirthDay,String birth_Year ) throws InterruptedException {
    	obj.Traveller_day();
    	obj.traveller_year();
    	
    }
    
    @And("^User enter (.*) within range$")
    public void User_enter_Passport_ID_within_range(String Passport_ID) throws InterruptedException {
    	obj.passport();
    	
    	
    }
    
    
    @And("^User enter (.*) from dropdown issueyear.$")
    public void User_enter_Inssu_yr_from_dropdown_issueyear(String Inssu_yr) throws InterruptedException{
    	obj.pass_issu_yr();
    	
    }
    
    
    @And("^User select payment method as Pay Later$")
    public void User_select_payment_method_as_Pay_Later() throws InterruptedException {
    	obj.arrow_down_key();
    	obj.payment_method();
    	
    }
    
    @And("^User click on agree terms and conditions checkbox$")
    public void User_click_on_agree_terms_and_conditions_checkbox() throws InterruptedException {
    	obj.booking_done();
    	
    }
    
    @And("^click on Booking confirm$")
    public void click_on_Booking_confirm() throws InterruptedException {
    	obj.confirm_button();
    	
    }
    
    
    @Then("^Booking must be success$")
    public void Booking_must_be_success() {
    	System.out.println("Booking must be success");
    }
    
    
	
}

