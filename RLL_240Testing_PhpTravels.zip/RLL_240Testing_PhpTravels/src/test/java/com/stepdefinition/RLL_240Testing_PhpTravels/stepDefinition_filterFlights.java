package com.stepdefinition.RLL_240Testing_PhpTravels;
import com.hooks_phpTravels.Hooks;
//import com.hooks_phpTravels.Hooks;
import com.pages.RLL_240Testing_PhpTravels.filterPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class stepDefinition_filterFlights {
filterPage filter= new filterPage(Hooks.driver);
	


	@And("User selects all flights")
	public void user_selects_all_flights() throws InterruptedException {
		Thread.sleep(2000);
		 filter.selectingdirect();
		Thread.sleep(2000);
		
	}

	@And("User sorts flights from high to low")
	public void user_sorts_flights_from_high_to_low() throws InterruptedException {
		Thread.sleep(2000);
		filter.selectinghightolow();
	}

	@And("User selects the first available flight")
	public void user_selects_the_first_available_flight() throws InterruptedException {
		Thread.sleep(2000);
		filter.selectingflight();
    	Thread.sleep(8000);

	}

	@Then("The flight should be selected successfully")
	public void the_flight_should_be_selected_successfully() {
		// Verify flight selection success
		 //Example: Assert.assertTrue(driver.findElement(By.id("success_message")).isDisplayed());
	}
}



