package com.stepdefinition.RLL_240Testing_PhpTravels;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.pages.RLL_240Testing_PhpTravels.searchHotelsPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition_searchHotel {
	WebDriver wd;
	searchHotelsPage searchHotels = new searchHotelsPage();
    Logger log1;
 
 
    public void init(WebDriver wd) {
        this.wd = wd;
		log1=Logger.getLogger(stepDefinition_searchHotel.class);
}
 
    @Given("the user is in browser")
    
    public void the_user_is_in_browser() {
        wd = new FirefoxDriver();
        searchHotels.init(wd);
        log1.info("the user is in browser");
       
    }
        
    @When("Launch PHP Travels")
    public void Launch_PHP_Travels() {
    	searchHotels.Launch_PHP_Travels();  
        searchHotels = new searchHotelsPage();
 
    }
   
    //searchHotels.Launch_PHP_Travels();
    @And("The user navigates to Hotels Module")
    public void The_user_navigates_to_Hotels_Module() {
        searchHotels.second_link();
    }
    
//    @When("the user enters as the location(.*) ")
//    public void the_user_enters_as_the_location {
//        searchHotels.Search_By_City();
//        // Add logic to select the location based on the input parameter
//    }
    
    @When("the user enters as the location(.*)")
    public void the_user_enters_as_the_location() {
    	searchHotels.Search_By_City();
    }
 
    @When("selects Checkin Date(.*)")
    public void selects_Checkin_Date(String checkinDate) {
        searchHotels.Checkin_calender();
        // Add logic to select the check-in date based on the input parameter
    }
 
    @When("selects Checkout Date(.*)")
    public void selects_Checkout_Date(String checkoutDate) {
        searchHotels.Checkout_calender();
        // Add logic to select the check-out date based on the input parameter
    }
 
    @When("selects Number of Rooms {string}")
    public void selects_number_of_rooms(String noOfRooms) {
        // Add logic to select the number of rooms based on the input parameter
    }
 
    @When("selects Number of Adults {string}")
    public void selects_number_of_adults(String noOfAdults) {
        // Add logic to select the number of adults based on the input parameter
    }
 
    @When("selects Number of Children {string}")
    public void selects_number_of_children(String noOfChildren) {
        // Add logic to select the number of children based on the input parameter
    }
 
    @When("selects Child Age {string}")
    public void selects_child_age(String childAge) {
        // Add logic to select the child age based on the input parameter
    }
 
    @When("clicks on Nationality")
    public void clicks_on_nationality() {
        // Add logic to click on nationality dropdown
    }
 
    @When("selects Nationality {string}")
    public void selects_nationality(String nationality) {
        // Add logic to select the nationality based on the input parameter
    }
 
    @When("clicks the search button")
    public void clicks_the_search_button() {
        searchHotels.Search();
    }
 
    @Then("the user should see {string} in the search box")
    public void user_should_see_in_the_search_box(String expectedResult) {
        // Add logic to verify the expected result in the search box
    }
}
