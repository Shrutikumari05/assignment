package com.stepdefinition.RLL_240Testing_PhpTravels;

import org.openqa.selenium.WebDriver;

//import com.hooks_phpTravels.Hooks;
import com.pages.RLL_240Testing_PhpTravels.bookingPage;

import io.cucumber.java.Before;
import io.cucumber.java.en.Then;
public class stepDefinitionFlightBooking {
	
    WebDriver driver;
	bookingPage booking = new bookingPage(driver);
	
//	@Before
//	public stepDefinitionFlightBooking(){
//	     driver=ChromeDriver();
//	}
	    
	    @Then("^Field enter (.*) and (.*)$")
	    public void field_enter_siva_and_kumari(String Firstname1,String Lastname1  ) throws InterruptedException {
	         Thread.sleep(2000);
	    	System.out.println(Firstname1);
	    	System.out.println(Lastname1);
	    	 booking.Firstname(Firstname1);
	         booking.lastname(Lastname1);
	    }
	    //   ("^I enter the last (.*) name$")
	    @Then("^User enter (.*) and (.*) in field$")
	    public void user_enter_siva_gmail_com_and_in_field(String Email_1,String Phone_1) {
	    	 booking.email(Email_1 );
	         booking.phone(Phone_1);
	    }

	    @Then("^User should enter1 (.*)$")
	    public void user_should_enter1_kharadi_bypass_pune(String Address1) {
	    	 booking.address(Address1);
	    	
	    }

	    @Then("^Do enter (.*) and (.*) on$")
	    public void do_enter_india_and_india_on(String Nation_ality2, String Current_Country2) throws InterruptedException {
	    	booking.Nationality(Nation_ality2);
	    	Thread.sleep(300);
	        booking.currentCountry(Current_Country2);  
	    
	    }

	    @Then("^User enter (.*) from dropdowns$")
	    public void user_enter_miss_from_dropdowns(String Title1) throws InterruptedException {
	    	Thread.sleep(800);
	    	System.out.println(Title1);
	    	 booking.Title(Title1);
	    }

	    @Then("^User entered information as (.*) and (.*)$")
	    public void user_entered_information_as_punam_and_suryawanshi(String Traveller_F1, String Traveller_L1) throws InterruptedException {
	        Thread.sleep(800);
	        booking.Fname(Traveller_F1);
	        booking.Lname(Traveller_L1);
	    }

	    @Then("^enters (.*) and (.*) Dec$")
	    public void enters_india_and_dec(String Nationality1,String Date_of_birth1) throws InterruptedException {
	    	Thread.sleep(800);
	    	 booking.traveller_Nationality();
	    	 Thread.sleep(300);
	         booking.dob();
	    }

	    @Then("^enter (.*) and (.*) From DropDown$")
	    public void enter_and_from_drop_down(String BirthDay1, String birth_Year1) throws InterruptedException {
	    	Thread.sleep(8000);
	    	  booking.Traveller_day();
	    	  Thread.sleep(300);
	          booking.traveller_year();
	      
	    }

	    @Then("^User enter (.*) within range$")
	    public void user_enter_within_range(String Passport_ID1) throws InterruptedException {
	    	Thread.sleep(8000);
	    	booking.passport(Passport_ID1);
	    }

	    @Then("^User enter (.*) from dropdown issueyear$")
	    public void user_enter_from_dropdown_issueyear(String Inssu_yr1) throws InterruptedException {
	    	Thread.sleep(300);
	    	booking.pass_issu_yr();
	    }

	    @Then("User select payment method as Pay Later1")
	    public void user_select_payment_method_as_pay_later1() throws InterruptedException {
	    	Thread.sleep(300);
	    	 booking.payment_method();
	    }

	    @Then("User click on agree terms and conditions checkbox1")
	    public void user_click_on_agree_terms_and_conditions_checkbox1() throws InterruptedException {
	    	Thread.sleep(300);
	    	 booking.booking_done();
	    }

	    @Then("click on Booking confirm1")
	    public void click_on_booking_confirm1() throws InterruptedException {
	    	Thread.sleep(300);
	    	booking.confirm_button();
	    }

	    @Then("Booking must be success1")
	    public void booking_must_be_success1() {
	       
	    }
	     
	}


