package com.stepdefinition.RLL_240Testing_PhpTravels;

import org.openqa.selenium.WebDriver;

//import com.hooks_phpTravels.Hooks;
import com.pages.RLL_240Testing_PhpTravels.bookingPage;

import io.cucumber.java.Before;
import io.cucumber.java.en.Then;
public class stepDefinitionFlightBooking {
	
    WebDriver driver;
	bookingPage booking = new bookingPage(driver);
	
//	@Before
//	public stepDefinitionFlightBooking(){
//	     driver=ChromeDriver();
//	}
	    
	    @Then("^Field enter (.*) and (.*)$")
	    public void field_enter_siva_and_kumari(String Firstname,String Lastname  ) throws InterruptedException {
	         Thread.sleep(2000);
	    	System.out.println(Firstname);
	    	System.out.println(Lastname);
	    	 booking.Firstname(Firstname);
	         booking.lastname(Lastname);
	    }
	    //   ("^I enter the last (.*) name$")
	    @Then("^User enter (.*) and (.*) in field$")
	    public void user_enter_siva_gmail_com_and_in_field(String Email,String Phone) {
	    	 booking.email(Email );
	         booking.phone(Phone);
	    }

	    @Then("^User should enter1 (.*)$")
	    public void user_should_enter1_kharadi_bypass_pune(String Address) {
	    	 booking.address(Address);
	    	
	    }

	    @Then("^Do enter (.*) and (.*) on$")
	    public void do_enter_india_and_india_on(String Nation_ality1, String Current_Country) throws InterruptedException {
	    	booking.Nationality(Nation_ality1);
	    	Thread.sleep(300);
	        booking.currentCountry(Current_Country);  
	    
	    }

	    @Then("^User enter (.*) from dropdowns$")
	    public void user_enter_miss_from_dropdowns(String Title) throws InterruptedException {
	    	Thread.sleep(800);
	    	System.out.println(Title);
	    	 booking.Title(Title);
	    }

	    @Then("^User entered information as (.*) and (.*)$")
	    public void user_entered_information_as_punam_and_suryawanshi(String Traveller_F, String Traveller_L) throws InterruptedException {
	        Thread.sleep(800);
	        booking.Fname(Traveller_F);
	        booking.Lname(Traveller_L);
	    }

	    @Then("^enters (.*) and (.*) Dec$")
	    public void enters_india_and_dec(String Nationality,String Date_of_birth) throws InterruptedException {
	    	Thread.sleep(800);
	    	 booking.traveller_Nationality();
	    	 Thread.sleep(300);
	         booking.dob();
	    }

	    @Then("^enter (.*) and (.*) From DropDown$")
	    public void enter_and_from_drop_down(String BirthDay, String birth_Year) throws InterruptedException {
	    	Thread.sleep(8000);
	    	  booking.Traveller_day();
	    	  Thread.sleep(300);
	          booking.traveller_year();
	      
	    }

	    @Then("^User enter (.*) within range$")
	    public void user_enter_within_range(String Passport_ID) throws InterruptedException {
	    	Thread.sleep(8000);
	    	booking.passport(Passport_ID);
	    }

	    @Then("^User enter (.*) from dropdown issueyear$")
	    public void user_enter_from_dropdown_issueyear(String Inssu_yr) throws InterruptedException {
	    	Thread.sleep(300);
	    	booking.pass_issu_yr();
	    }

	    @Then("User select payment method as Pay Later")
	    public void user_select_payment_method_as_pay_later() throws InterruptedException {
	    	Thread.sleep(300);
	    	 booking.payment_method();
	    }

	    @Then("User click on agree terms and conditions checkbox")
	    public void user_click_on_agree_terms_and_conditions_checkbox() throws InterruptedException {
	    	Thread.sleep(300);
	    	 booking.booking_done();
	    }

	    @Then("click on Booking confirm")
	    public void click_on_booking_confirm() throws InterruptedException {
	    	Thread.sleep(300);
	    	booking.confirm_button();
	    }

	    @Then("Booking must be success")
	    public void booking_must_be_success() {
	       
	    }
	     
	}


