//package com.stepdefinition.RLL_240Testing_PhpTravels;
//
//import java.io.IOException;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
//
//import com.pages.RLL_240Testing_PhpTravels.blogsPage;
//
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class StepDefinition_Blogs {
//    WebDriver driver;
//    blogsPage phpTravelsBlogs;
//
//    @Given("the user is on the PHP Travels homepage")
//    public void the_user_is_on_the_php_travels_homepage() throws IOException {
//        driver = new ChromeDriver(); // Adjust as needed for your WebDriver setup
//        phpTravelsBlogs = new blogsPage(driver);
//        phpTravelsBlogs.launch();
//    }
//
//    @When("the user clicks on the Blogs link")
//    public void the_user_clicks_on_the_blogs_link() throws InterruptedException {
//        phpTravelsBlogs.clickBlogUrl();
//    }
//
//    
//   @Then("the user should see the PHP Travels blog header")
//    public void the_user_should_see_the_php_travels_blog_header() {
//        WebElement headerElement = driver.findElement(By.xpath("//h2[@class='sec__title text-white' and text()='PHPTRAVELS Blogs']"));
//        
//        // Extract the text from the header element
//       String headerText = headerElement.getText();
//        
//       // Use assertEquals to check for an exact match
//        Assert.assertEquals("PHPTRAVELS Blogs", headerText, "Header text does not match!");
//    }
//
//
//    @When("the user clicks on the View More button")
//    public void the_user_clicks_on_the_view_more_button() throws InterruptedException {
//        phpTravelsBlogs.clickViewMoreButton();
//    }
//
//
//
//
//   
//    @When("the user clicks on the arrow to open the any blog")
//    public void the_user_clicks_on_the_arrow_to_open_any_blog() throws InterruptedException {
//        phpTravelsBlogs.clickArrowToOpenBlog1();
//    }
//
//    @Then("the user should see the blog content")
//    public void the_user_should_see_the_blog_content() {
//        WebElement headerElement = driver.findElement(By.xpath("//strong[contains(text(),\"Kinda 2,000 Years After His Death\")]"));
//        
//        // Extract the text from the header element
//        String headerText = headerElement.getText();
//        
//        // Check if the header text contains the expected string
//        Assert.assertTrue(headerText.contains("Kinda 2,000 Years After His Death"), "Header text does not match!");
//    }
//
//}
    
package com.stepdefinition.RLL_240Testing_PhpTravels;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.pages.RLL_240Testing_PhpTravels.blogsPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition_Blogs {
    WebDriver driver;
    blogsPage phpTravelsBlogs;
    ExtentReports extent;
    ExtentTest test;

    public StepDefinition_Blogs() {
        // Initialize ExtentReports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("reports/extentReport_Blogs.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
    }

    @Given("the user is on the PHP Travels homepage")
    public void the_user_is_on_the_php_travels_homepage() throws IOException {
        driver = new ChromeDriver(); // Adjust as needed for your WebDriver setup
        phpTravelsBlogs = new blogsPage(driver);
        phpTravelsBlogs.launch();
        test = extent.createTest("User navigates to PHP Travels homepage");
        test.pass("Successfully launched the homepage.");
    }

    @When("the user clicks on the Blogs link")
    public void the_user_clicks_on_the_blogs_link() throws InterruptedException {
        phpTravelsBlogs.clickBlogUrl();
        test = extent.createTest("User clicks on Blogs link");
        test.pass("Blogs link clicked successfully.");
    }

    @Then("the user should see the PHP Travels blog header")
    public void the_user_should_see_the_php_travels_blog_header() {
        WebElement headerElement = driver.findElement(By.xpath("//h2[@class='sec__title text-white' and text()='PHPTRAVELS Blogs']"));
        
        // Extract the text from the header element
        String headerText = headerElement.getText();
        
        // Use assertEquals to check for an exact match
        Assert.assertEquals("PHPTRAVELS Blogs", headerText, "Header text does not match!");
        test = extent.createTest("Verify blog header");
        test.pass("Blog header is displayed correctly: " + headerText);
    }

    @When("the user clicks on the View More button")
    public void the_user_clicks_on_the_view_more_button() throws InterruptedException {
        phpTravelsBlogs.clickViewMoreButton();
        test = extent.createTest("User clicks on View More button");
        test.pass("View More button clicked successfully.");
    }

    @When("the user clicks on the arrow to open any blog")
    public void the_user_clicks_on_the_arrow_to_open_any_blog() throws InterruptedException {
        phpTravelsBlogs.clickArrowToOpenBlog1();
        test = extent.createTest("User clicks on arrow to open blog");
        test.pass("Arrow clicked to open blog successfully.");
    }

    @Then("the user should see the blog content")
    public void the_user_should_see_the_blog_content() {
        WebElement headerElement = driver.findElement(By.xpath("//strong[contains(text(),\"Kinda 2,000 Years After His Death\")]"));
        
        // Extract the text from the header element
        String headerText = headerElement.getText();
        
        // Check if the header text contains the expected string
        Assert.assertTrue(headerText.contains("Kinda 2,000 Years After His Death"), "Header text does not match!");
        test = extent.createTest("Verify blog content");
        test.pass("Blog content is displayed correctly: " + headerText);
        extent.flush();
    }

    // After all tests, flush the reports
    @io.cucumber.java.After
    public void tearDown() {
       
        if (driver != null) {
            driver.quit();
        }
    }
}

