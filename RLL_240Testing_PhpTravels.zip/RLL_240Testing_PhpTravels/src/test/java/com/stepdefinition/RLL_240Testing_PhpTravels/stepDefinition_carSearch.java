package com.stepdefinition.RLL_240Testing_PhpTravels;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.pages.RLL_240Testing_PhpTravels.carSearch;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition_carSearch {
	 WebDriver driver;
	  carSearch obj;
	  Logger log;
	  
	 By invalidAct=By.xpath("//li[contains(text(),\"No results found\")]");
	   
	   @Before
	   public void init() {
		   driver = new ChromeDriver();  
		   obj=new carSearch(driver);
		   log = Logger.getLogger(stepDefinition_carSearch.class);
	   }
	
	   
	    @Given("^I am on Cars page$")
	    public void i_am_on_Cars() throws InterruptedException {
	    	System.out.println("hello");
	    	obj.launch();
	    	Thread.sleep(500);
	    	obj.click_car();
	    	log.info("pass");
	    	
	    }
	     
	    @When("^I select (.*) in the From Airport fields$")
       public void i_am_on_from_airport(String fromAirport) throws InterruptedException {
	    	obj.selectairport(fromAirport);
	    	
	    }
	    @When("^I select (.*) in the To Location field$")
	    public void location_field(String toLocation) throws InterruptedException {
	    	obj.selectToLocation(toLocation);
	    	
	    }
	    @When("^I set the pick-up date$") 
	    public void set_pick_up() {
	    	obj.pickupdate();
	    	
	    }
	    @When("^I enter times$") 
	    public void enter_pickup_time() {
	    	obj.pickuptime();
	    
	    	
	    }
	    @When("^I set the drop-off date$")
	    public void set_drop_off() {
	    	obj.toDate();
	    
	    }
	    @When("^I enter time$")
	    public void i_enter_drop_time() {
	    	obj.droptime();
	    }
	    @When("^I add num of Adults and num of Children from travellers dropdown$")
	    public void I_add_num_of_adult() {
	    	System.out.println("adult");
	    	
	    }
	    @And("^I click the search button$")
	    public void i_click_search_btn() throws InterruptedException {
	    	obj.search();
	    }
	    @Then("^the search results (.*) relevant to the (.*) input$")
       public void show_relevent_result(String actualResult, String expectedResult) {
	            try {
	               
	                WebElement messageElement = driver.findElement(By.xpath(String.format("//*[contains(text(),'%s')]", actualResult)));
	                System.out.println("dekhooooo"+ messageElement);
	                String actualMessage = messageElement.getText();
	               
	                Assert.assertEquals(actualMessage, expectedResult, "The actual message match the expected result.");
	            } catch (NoSuchElementException e) {
	                Assert.fail(String.format("Expected message '%s' was not found on the page.", expectedResult));
	            }
	            log.info("Assertion successfully");
	        }
	    @After
	    public void tearDown() {
	    	if(driver!=null) {
	    		log.info("close the browser");
	    		driver.quit();
	    		log.info("Browser closed sucessfully");
	    	}
	    }
	 }  	

