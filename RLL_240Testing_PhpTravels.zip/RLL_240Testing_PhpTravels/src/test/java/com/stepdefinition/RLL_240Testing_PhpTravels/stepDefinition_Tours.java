package com.stepdefinition.RLL_240Testing_PhpTravels;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.pages.RLL_240Testing_PhpTravels.searchToursPage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition_Tours {
	WebDriver driver;
	searchToursPage obj = new searchToursPage();
	Logger log;
	private static ExtentReports extent;
    private static ExtentTest test;
    private static ExtentHtmlReporter htmlReporter;
 
    @Before
    public void setUp() {
        
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        log = Logger.getLogger(stepDefinition_Tours.class);
 
        
        htmlReporter = new ExtentHtmlReporter("reports/extentReport.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        test = extent.createTest("PHP Travels Tour Test");
    }
 
    @Given("the user is in browser pages")
    public void the_user_is_in_browser_pages() {
        obj.init1(driver);
        test.info("User is in browser");
    }
 
    @When("the user Launch the app PHP Travels")
    public void the_user_Launch_the_app_php_travels() throws IOException {
        obj.Launch_PHP_Travels();
        test.info("Launched PHP Travels app");
        extent.flush();
    }
 
    @And("the user should navigate")
    public void the_user_should_navigate() throws InterruptedException {
        obj.second_link();
        obj.Find_best_tours();
        log.info("Passed navigation step");
        test.info("Clicked on 'Find Best Tours' link");
        Thread.sleep(3000);
    }
 
    @And("^user selects a (.*) by using search by city$")
    public void user_selects_city_as_a_city_by_using_search_by_city(String city) throws InterruptedException {
        obj.search_by_city(city);
        obj.search_city();
        test.info("Searched for city: " + city);
    }
 
    @Then("user click on the search button")
    public void user_click_on_the_search_button() throws InterruptedException {
        obj.search();
        test.info("Clicked on the search button");
        Thread.sleep(5000);
    }
 
    @After
    public void tearDown() {
         
        driver.quit();
    }
}