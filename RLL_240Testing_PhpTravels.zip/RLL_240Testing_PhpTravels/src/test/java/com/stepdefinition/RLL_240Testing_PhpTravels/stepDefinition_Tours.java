package com.stepdefinition.RLL_240Testing_PhpTravels;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import com.pages.RLL_240Testing_PhpTravels.searchToursPage;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition_Tours {
	WebDriver driver;
	searchToursPage obj = new searchToursPage();
	//Hooks info = new Hooks(info.driver);
	Logger log;
	@Before
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        log = Logger.getLogger(stepDefinition_Tours .class);
    }
	@Given("the user is in browser")
	public void the_user_is_in_browser() {
		obj.init1(driver);

	}
	@When("the user Launch the app PHP Travels")
	public void the_user_Launch_the_app_php_travels() {
		obj.Launch_PHP_Travels();
	}
	@And("the user should navigate")
	public void the_user_should_navigate() throws InterruptedException {
		obj.second_link();
//		WebElement cc = driver.findElement(By.xpath("//*[contains(text(),\"Find Best Tours\")]"));
//	String validText = "Find Best Tours";
//	assertEquals(validText, "Find Best Tours");
    obj.Find_best_tours();
    log.info("passed");
    Thread.sleep(3000);
        }
	@And("^user selects a (.*) by using search by city$")
	public void user_selects_city_as_a_city_by_using_search_by_city(String city) throws InterruptedException {
		obj.search_by_city(city);
		obj.search_city();

	}
//	@And("user selects default date")
//    public void user_selects_defaults_date() {
//		obj.click_on_calender1();
//		obj.date();
//		obj.calender();
//		
//		//driver.findElement(By.id("date")).click();
//        //wd.findElement(By.id("calender")).click();
//    }
//    @And("the user selects a date")
//    public void the_user_selects_a_date() {
//    	obj.calender();
//        //driver.findElement(By.id("date")).click();
//    }
//	@And("I select the number of travelers")
//	public void i_select_the_number_of_travelers() {
//		obj.travelers();
//		obj.adults_minus();
//		obj.adults_minus();
//		obj.childs_plus();
//		obj.childs_minus();
//	}
	@Then("user click on the search button")
	public void user_click_on_the_search_button() throws InterruptedException {
		obj.search();
		Thread.sleep(5000);
	}
}
