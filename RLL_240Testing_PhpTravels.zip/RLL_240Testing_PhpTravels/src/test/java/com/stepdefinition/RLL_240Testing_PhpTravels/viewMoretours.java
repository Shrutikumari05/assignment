package com.stepdefinition.RLL_240Testing_PhpTravels;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.pages.RLL_240Testing_PhpTravels.viewMorePage;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class viewMoretours {

		WebDriver wd;
		viewMorePage obj1 = new viewMorePage();
		Logger log;
		@Before
	    public void setUp() {
	        wd = new FirefoxDriver();
	        wd.manage().window().maximize();
	        log = Logger.getLogger(viewMoretours.class);
	        wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    }
		 @Given("the user launches the PHP Travels site")
		    public void the_user_launches_the_php_travels_site() {
		        wd.manage().window().maximize();
		        obj1.init2(wd);
		        obj1.Launch_PHP_Travels1();
		        log.info("PHPTavels launched successfully");
		    }
		    @When("the user clicks on the search button")
		    public void the_user_clicks_on_the_search_button() throws InterruptedException {
		        obj1.search1();
		    }
		    @When("the user clicks on view more")
		    public void the_user_clicks_on_view_more() throws InterruptedException {
		        obj1.viewMore1();
		        wd.quit();    
		        }
		    @And("validate the text which is related to searched city")
	       public void validate_the_text_which_is_related_to_searched_city() {
		    	WebDriverWait wait = new WebDriverWait(wd, Duration.ofSeconds(10));
		    	WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='h3 fw-bold mb-0 py-1']")));	
	       	
	    	WebElement title = wd.findElement(By.xpath("//div[@class=\"h3 fw-bold mb-0 py-1\"]"));
		        Assert.assertEquals(title.getText(), "Baku City Tour");
	 
		         
		        WebElement price = wd.findElement(By.xpath("//span[contains(text(), 'From USD 0.00')]"));
	        Assert.assertEquals(price.getText(), "From USD 0.00");
		    }
	 
		    public void tearDown() {
		        if (wd != null) {
		            wd.quit();
	        }
		    }
}

		   
		    

