package Runner_artifact;




import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		dryRun=false,
		monochrome=true,
		features="src/test/resource/Feature",
        glue="Step_defination",	
        plugin = {"pretty", "html:target/cucumber-reports.html"},
        tags="@Home_Page or @Filtered_Flight_Page"
		)


public class Runner_Junit{

}
