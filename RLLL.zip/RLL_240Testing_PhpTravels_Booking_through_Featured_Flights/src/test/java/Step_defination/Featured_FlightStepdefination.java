//package Step_defination;
//
//import java.io.File;
//import java.io.IOException;
//
//import org.apache.log4j.Logger;
//import org.openqa.selenium.OutputType;
//import org.openqa.selenium.TakesScreenshot;
//import org.openqa.selenium.WebDriver;
//
//import com.google.common.io.Files;
//import com.hooks.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1.BaseTest;
//import com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1.Featured_Flight;
//
//
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//
//public class Featured_FlightStepdefination{
//	private BaseTest baseTest; // To manage WebDriver
//    private Featured_Flight obj;
//    Logger log;
//    WebDriver wd ;
//    
//   public Featured_FlightStepdefination() throws IOException {
//	   baseTest = new BaseTest(); // Initialize BaseTest
//   obj = new Featured_Flight(baseTest.getDriver()); 
//   log=Logger.getLogger(Featured_FlightStepdefination.class);
//   }
//   
//	   
//   
//	
//	@Given("I am on homepage of PHP Travels homepage")
//public void I_am_on_homepage_of_PHP_Travels_homepage() throws IOException {
//	obj.Launch_app();
//	
//
//	log.info("pass");
//	
//}
//
//
//@When("I should see Featured Flight section")
//public void I_should_see_Featured_Flight_section() {
//	
//	System.out.println("Wel-Come");
//}
//
//
//
//
//
//@When("I press the down key")
//public void I_press_the_down_key() {
//	obj.arrow_down();
//}
//
//
//
//
//@When("I select the first flight displayed")
//public void I_select_the_first_flight_displayed() {
//	obj.select_lahor();
//}
//
//
//@Then("I see flight details page")
//public void I_see_flight_details_page() {
//	System.out.println("This is list of Featured_Flights");
//}
//
//}
//
//
//
//


package Step_defination;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.google.common.io.Files;
import com.hooks.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1.BaseTest;
import com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1.Featured_Flight;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Featured_FlightStepdefination {
    private BaseTest baseTest; // To manage WebDriver
    private Featured_Flight obj;
    Logger log;
    WebDriver wd;

    // ExtentReports objects
    private static ExtentReports extent;
    private static ExtentTest test;

    public Featured_FlightStepdefination() throws IOException {
        baseTest = new BaseTest(); // Initialize BaseTest
        obj = new Featured_Flight(baseTest.getDriver());
        log = Logger.getLogger(Featured_FlightStepdefination.class);

        // Setup ExtentReports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("report/extentReport.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        test = extent.createTest("Featured Flight Test");
    }

    @Given("I am on homepage of PHP Travels homepage")
    public void I_am_on_homepage_of_PHP_Travels_homepage() throws IOException {
        obj.Launch_app();
        test.info("Launched PHP Travels homepage");
        log.info("Homepage launched");
    }

    @When("I should see Featured Flight section")
    public void I_should_see_Featured_Flight_section() {
        test.info("Checking Featured Flight section");
        System.out.println("Wel-Come");
    }

    @When("I press the down key")
    public void I_press_the_down_key() {
        obj.arrow_down();
        test.info("Pressed the down key");
    }

    @When("I select the first flight displayed")
    public void I_select_the_first_flight_displayed() {
        obj.select_lahor();
        test.info("Selected the first flight displayed");
    }

    @Then("I see flight details page")
    public void I_see_flight_details_page() {
        test.info("Flight details page displayed");
        System.out.println("This is list of Featured_Flights");
        extent.flush();
    }

    // Method to capture screenshots
    public void captureScreenshot(String testName) {
        try {
            TakesScreenshot ts = (TakesScreenshot) baseTest.getDriver();
            File source = ts.getScreenshotAs(OutputType.FILE);
            File destination = new File("screenshots/" + testName + ".png");
            Files.copy(source, destination);
            test.addScreenCaptureFromPath(destination.getAbsolutePath());
        } catch (IOException e) {
            log.error("Error capturing screenshot: " + e.getMessage());
        }
    }

    // Call this at the end of the test to flush reports
    public void flushReports() {
       
    }
}
