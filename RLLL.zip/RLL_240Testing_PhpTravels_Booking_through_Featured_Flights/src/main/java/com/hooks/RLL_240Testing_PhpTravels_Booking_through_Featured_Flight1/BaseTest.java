package com.hooks.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class BaseTest {
    protected WebDriver driver; 

    @Before
    public void setUp() {
      
        driver = new EdgeDriver();
        driver.manage().window().maximize();
    }

    @After
    public void tearDown() {
       
    }

	public WebDriver getDriver() {
		// TODO Auto-generated method stub
		return null;
	}
    
    
}