package com.util.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1;

import java.time.Duration;

import org.openqa.selenium.WebDriver;

public class utils {
	WebDriver driver;
	
	public void implicitlyWait() {
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
}
	
}