package com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight1;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

import com.google.common.io.Files;


public class Featured_Flight{
	
	

	private WebDriver driver;

	By Flight_Click=By.xpath("//a[contains(text(),\"Flights\")]");
	By lahor_dubai_click=By.xpath("(//p[@class=\"m-0 text-hover\"])[1]");

	public Featured_Flight(WebDriver driver)  { // Constructor 
        this.driver = driver;
    
	
	
	}
	
	
	
	
	public void Launch_app() throws IOException {
		
		
	    
		driver=new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://phptravels.net/");
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/flights");
		File src=((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	    Files.copy(src, new File("./Screenshots/shot1.png"));
	
	}


	public void flight_click() throws InterruptedException, IOException  {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	driver.findElement(Flight_Click).click();
	

	Thread.sleep(3000);
	}
	public void arrow_down() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	Actions actions = new Actions(driver);
    actions.sendKeys(Keys.ARROW_DOWN).perform();}
    
    public void select_lahor() {
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	driver.findElement(lahor_dubai_click).click();
	

	}
	
	

	}

	





