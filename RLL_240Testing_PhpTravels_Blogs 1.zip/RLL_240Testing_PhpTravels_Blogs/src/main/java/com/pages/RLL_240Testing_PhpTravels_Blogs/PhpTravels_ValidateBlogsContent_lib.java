package com.pages.RLL_240Testing_PhpTravels_Blogs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PhpTravels_ValidateBlogsContent_lib {
	
WebDriver driver;
 
	

	By new_blog_list_blog3 = By.xpath("(//a[@class=\" waves-effect\"])[3]"); 
	By blog_title = By.xpath("//strong[contains(text(),\"The Tiber River’s Last Eel Fishermen\")]");
	By blog_image = By.xpath("//img[@class=\"w-100 rounded-2\"]");
	By blog_date = By.xpath("//div[@class=\"d-flex align-items-center justify-content-between\"]");
	By blog_content = By.xpath("//div[@class=\"card-body\"] ");
 
	
	
	public void clicknew_blog_list_blog3()
	{
		driver.findElement(new_blog_list_blog3).click();
	}
	public void validateblog_title()
	{
		
		
	}
	public void validateblog_image()
	{
		
		
	}
	public void validateblog_date()
	{
		
		
	}
	public void validateblog_content()
	{
		
		
	}

}

