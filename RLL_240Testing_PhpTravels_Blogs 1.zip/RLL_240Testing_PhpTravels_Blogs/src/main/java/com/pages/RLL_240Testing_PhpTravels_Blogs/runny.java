package com.pages.RLL_240Testing_PhpTravels_Blogs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class runny {public static void main(String[] args) throws InterruptedException {
	WebDriver wd;
	wd = new ChromeDriver() ;
	PhpTravels_Blogs_lib pag1=new PhpTravels_Blogs_lib( wd);
	pag1.launch();
    wd.manage().window().maximize();

	pag1.clickBlogUrl();
	Thread.sleep(10);
	pag1.clickViewMoreButton();
	Thread.sleep(1000);
	pag1.clickArrowToOpenBlog1();
	Thread.sleep(5000);
}

}
