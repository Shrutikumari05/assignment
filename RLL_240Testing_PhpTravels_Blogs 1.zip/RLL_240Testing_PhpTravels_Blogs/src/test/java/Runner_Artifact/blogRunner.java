package Runner_Artifact;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="src\\test\\resource\\com\\features\\Blogs.feature",
		glue="com.stepdefinition.RLL_240Testing_PhpTravels_Blogs"
		)
public class blogRunner {

}
