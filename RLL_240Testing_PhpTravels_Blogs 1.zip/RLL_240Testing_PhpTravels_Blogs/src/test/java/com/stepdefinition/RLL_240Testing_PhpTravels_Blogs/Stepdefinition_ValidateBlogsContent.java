//package com.stepdefinition.RLL_240Testing_PhpTravels_Blogs;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
//
//import com.pages.RLL_240Testing_PhpTravels_Blogs.PhpTravels_ValidateBlogsContent_lib;
//
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class Stepdefinition_ValidateBlogsContent {
//	 WebDriver driver = new ChromeDriver();
//	
//	
//	
//
//	   
//	    PhpTravels_ValidateBlogsContent_lib blogsPage = new PhpTravels_ValidateBlogsContent_lib();
//
//	    @When("I click on the third blog in the list")
//	    public void i_click_on_the_third_blog_in_the_list() {
//	        blogsPage.clicknew_blog_list_blog3();
//	    }
//
//	    @Then("I should see the blog title {string}")
//	     public void i_should_see_the_blog_title(String expectedTitle) {
//	       
//	    }
//
//	    @Then("I should see the blog image")
//	    public void i_should_see_the_blog_image() {
//	        boolean isImageDisplayed = driver.findElement(blogsPage.validateblog_image()).isDisplayed();
//	        Assert.assertTrue(isImageDisplayed);
//	    }
//
//	    @Then("I should see the blog date")
//	    public void i_should_see_the_blog_date() {
//	        boolean isDateDisplayed = driver.findElement(blogsPage.validateblog_date()).isDisplayed();
//	        Assert.assertTrue(isDateDisplayed);
//	    }
//
//	    @Then("I should see the blog content")
//	    public void i_should_see_the_blog_content() {
//	        boolean isContentDisplayed = driver.findElement(blogsPage.validateblog_content()).isDisplayed();
//	        Assert.assertTrue(isContentDisplayed);
//	    }
//	}
//
//
//	
//}
