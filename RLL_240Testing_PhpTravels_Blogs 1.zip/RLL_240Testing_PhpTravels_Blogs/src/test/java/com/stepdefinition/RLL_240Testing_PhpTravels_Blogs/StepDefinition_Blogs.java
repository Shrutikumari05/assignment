package com.stepdefinition.RLL_240Testing_PhpTravels_Blogs;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_PhpTravels_Blogs.PhpTravels_Blogs_lib;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition_Blogs  {

    WebDriver driver;
    PhpTravels_Blogs_lib phpTravelsBlogs;

    @Given("the user is on the PHP Travels homepage")
    public void the_user_is_on_the_php_travels_homepage() {
        driver = new ChromeDriver(); // Adjust as needed for your WebDriver setup
        phpTravelsBlogs = new PhpTravels_Blogs_lib(driver);
        phpTravelsBlogs.launch();
    }

    @When("the user clicks on the Blogs link")
    public void the_user_clicks_on_the_blogs_link() throws InterruptedException {
        phpTravelsBlogs.clickBlogUrl();
    }



    
    
   @Then("the user should see the PHP Travels blog header")
    public void the_user_should_see_the_php_travels_blog_header() {
        WebElement headerElement = driver.findElement(By.xpath("//h2[@class='sec__title text-white' and text()='PHPTRAVELS Blogs']"));
        
        // Extract the text from the header element
       String headerText = headerElement.getText();
        
       // Use assertEquals to check for an exact match
        assertEquals("PHPTRAVELS Blogs", headerText, "Header text does not match!");
    }




   

    @When("the user clicks on the View More button")
    public void the_user_clicks_on_the_view_more_button() throws InterruptedException {
        phpTravelsBlogs.clickViewMoreButton();
    }




   
    @When("the user clicks on the arrow to open the any blog")
    public void the_user_clicks_on_the_arrow_to_open_any_blog() throws InterruptedException {
        phpTravelsBlogs.clickArrowToOpenBlog1();
    }

    @Then("the user should see the blog content")
    public void the_user_should_see_the_blog_content() {
        WebElement headerElement = driver.findElement(By.xpath("//strong[contains(text(),\"Kinda 2,000 Years After His Death\")]"));
        
        // Extract the text from the header element
        String headerText = headerElement.getText();
        
        // Check if the header text contains the expected string
        assertTrue(headerText.contains("Kinda 2,000 Years After His Death"), "Header text does not match!");
    }

}
    
//    // Clean up after tests
//    @After
//    public void tearDown() {
//        if (driver != null) {
//            driver.quit();
//        }
//    }
//}
