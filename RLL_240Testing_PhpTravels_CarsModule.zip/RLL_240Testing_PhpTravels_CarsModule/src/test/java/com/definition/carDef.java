//package com.definition;
//
//import java.io.IOException;
//
//import org.apache.log4j.Logger;
//import org.openqa.selenium.Alert;
//import org.openqa.selenium.By;
//
//import org.openqa.selenium.NoSuchElementException;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
//
//import com.pages.carPage;
//
//import io.cucumber.java.Before;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class carDef {
//	  WebDriver driver;
//	  carPage obj;
//	  Logger log;
//	  
//	 By invalidAct=By.xpath("//li[contains(text(),\"No results found\")]");
//	   
//	   @Before
//	   public void init() {
//		   driver = new ChromeDriver();  
//		   obj=new carPage(driver);
//		   log = Logger.getLogger(carDef.class);
//	   }
//	
//	   
//	    @Given("^I am on Cars page$")
//	    public void i_am_on_Cars() throws InterruptedException, IOException {
//	    	System.out.println("hello");
//	    	obj.launch();
//	    	Thread.sleep(500);
//	    	obj.click_car();
//	    	log.info("pass");
//	    	
//	    }
//	     
//	    @When("^I select (.*) in the From Airport fields$")
//        public void i_am_on_from_airport(String fromAirport) throws InterruptedException {
//	    	obj.selectairport(fromAirport);
//	    	
//	    }
//	    @When("^I select (.*) in the To Location field$")
//	    public void location_field(String toLocation) throws InterruptedException {
//	    	obj.selectToLocation(toLocation);
//	    	
//	    }
//	    @When("^I set the pick-up date$") 
//	    public void set_pick_up() {
//	    	obj.pickupdate();
//	    	
//	    }
//	    @When("^I enter times$") 
//	    public void enter_pickup_time() {
//	    	obj.pickuptime();
//	    
//	    	
//	    }
//	    @When("^I set the drop-off date$")
//	    public void set_drop_off() {
//	    	obj.toDate();
//	    
//	    }
//	    @When("^I enter time$")
//	    public void i_enter_drop_time() {
//	    	obj.droptime();
//	    }
//	    @When("^I add num of Adults and num of Children from travellers dropdown$")
//	    public void I_add_num_of_adult() {
//	    	System.out.println("adult");
//	    	
//	    }
//	    @And("^I click the search button$")
//	    public void i_click_search_btn() throws InterruptedException {
//	    	obj.search();
//	    }
//	    @Then("^the search results (.*) relevant to the (.*) input$")
//        public void show_relevent_result(String actualResult, String expectedResult) {
//	            try {
//	               
//	                WebElement messageElement = driver.findElement(By.xpath(String.format("//*[contains(text(),'%s')]", actualResult)));
//	                System.out.println("dekhooooo"+ messageElement);
//	                String actualMessage = messageElement.getText();
//	               
//	                Assert.assertEquals(actualMessage, expectedResult, "The actual message match the expected result.");
//	            } catch (NoSuchElementException e) {
//	                Assert.fail(String.format("Expected message '%s' was not found on the page.", expectedResult));
//	            }
//	            log.info("Assertion successfully");
//	        }
//	    }  	

package com.definition;

import java.io.IOException;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import com.pages.carPage;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class carDef {
    WebDriver driver;
    carPage obj;
    Logger log;
    ExtentReports extent;
    ExtentTest test;

    By invalidAct = By.xpath("//li[contains(text(),\"No results found\")]");

    @Before
    public void init() {
        driver = new ChromeDriver();
        obj = new carPage(driver);
        log = Logger.getLogger(carDef.class);

        // Initialize ExtentReports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("reports/extentReport.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
    }

    @Given("^I am on Cars page$")
    public void i_am_on_Cars() throws InterruptedException, IOException {
        test = extent.createTest("Navigate to Cars Page");
        obj.launch();
        Thread.sleep(500);
        obj.click_car();
        log.info("Navigated to Cars page.");
        test.pass("Successfully navigated to Cars page.");
        extent.flush();
    }

    @When("^I select (.*) in the From Airport fields$")
    public void i_am_on_from_airport(String fromAirport) throws InterruptedException {
        test = extent.createTest("Select From Airport: " + fromAirport);
        obj.selectairport(fromAirport);
        test.pass("Selected From Airport: " + fromAirport);
    }

    @When("^I select (.*) in the To Location field$")
    public void location_field(String toLocation) throws InterruptedException {
        test = extent.createTest("Select To Location: " + toLocation);
        obj.selectToLocation(toLocation);
        test.pass("Selected To Location: " + toLocation);
    }

    @When("^I set the pick-up date$")
    public void set_pick_up() {
        test = extent.createTest("Set Pick-Up Date");
        obj.pickupdate();
        test.pass("Pick-Up Date set.");
    }

    @When("^I enter times$")
    public void enter_pickup_time() {
        test = extent.createTest("Enter Pickup Time");
        obj.pickuptime();
        test.pass("Pickup Time entered.");
        
    }

    @When("^I set the drop-off date$")
    public void set_drop_off() {
        test = extent.createTest("Set Drop-Off Date");
        obj.toDate();
        test.pass("Drop-Off Date set.");
    }

    @When("^I enter time$")
    public void i_enter_drop_time() {
        test = extent.createTest("Enter Drop Time");
        obj.droptime();
        test.pass("Drop Time entered.");
    }

    @When("^I add num of Adults and num of Children from travellers dropdown$")
    public void I_add_num_of_adult() {
        test = extent.createTest("Add Number of Adults and Children");
        // Implement logic here
        test.pass("Number of Adults and Children added.");
    }

    @And("^I click the search button$")
    public void i_click_search_btn() throws InterruptedException {
        test = extent.createTest("Click Search Button");
        obj.search();
        test.pass("Search button clicked.");
    }

    @Then("^the search results (.*) relevant to the (.*) input$")
    public void show_relevent_result(String actualResult, String expectedResult) {
        test = extent.createTest("Verify Search Results");
        try {
            WebElement messageElement = driver.findElement(By.xpath(String.format("//*[contains(text(),'%s')]", actualResult)));
            String actualMessage = messageElement.getText();
            Assert.assertEquals(actualMessage, expectedResult, "The actual message matches the expected result.");
            test.pass("Search results verified successfully.");
        } catch (NoSuchElementException e) {
            Assert.fail(String.format("Expected message '%s' was not found on the page.", expectedResult));
            test.fail("Expected message not found: " + expectedResult);
        }
        log.info("Assertion successfully completed.");
    }

    // After all tests, flush the reports
    public void tearDown() {
       // extent.flush();
    }
}
