package TestNgRunner;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features="src/test/resource/com/runner",
		glue="com.definition",
		tags="@validdata",
		monochrome=true
		)
 public class carRunner extends AbstractTestNGCucumberTests
	{

}
	