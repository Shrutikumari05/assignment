package com.pages;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

public class carPage {
	WebDriver wd;


	By car_link = By.xpath("//a[contains(text(),\"Cars\")]");
	By FromAirport=By.xpath("//div[@class=\"mt-1\"]");
	By	ToAirport=By.xpath("//span[contains(text(),\"Select\")]");
	By	PickupDate=By.xpath("//input[@id=\"cars_from_date\"]");
	//	By	pickpTime=By.xpath("//select[@id=\"cars_from_time\"]");
	By	DropOffDate =By.xpath("//input[@id=\"cars_to_date\"]");
	
	By	traveller=By.xpath("//p[@class=\"m-0 d-flex align-items-center gap-2\"]");
	By	search_Button=By.xpath("//button[contains(@class,'search_button w-100 btn btn-primary btn-m rounded-sm font-700 text-uppercase btn-full waves-effect')]");
	By mumbai=By.xpath("//input[@class=\"select2-search__field\" and @type=\"search\"]");
	By City_pune=By.xpath("//input[@class=\"select2-search__field\" and @type =\"search\"]");
    String time="";
	By select2SearchField = By.xpath("//input[@class=\"select2-search__field\" and @type=\"search\"]");
	By switchElement = By.xpath("(//th[@class=\"switch\"])[1]");
	By dayDateElement = By.xpath("(//td[@class=\"day \"])[9]");
	By dropOffDateElement = By.xpath("//*[@id=\"fadein\"]/div[6]/div[1]/table/tbody/tr[3]/td[3]");

	public  carPage(WebDriver wd){
		this.wd=wd;
		  wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	}

	public void launch() throws IOException {

		wd.get("https://phptravels.net/");
		wd.manage().window().maximize();
		File src=((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
	    Files.copy(src, new File("./Screenshot/shot1.png"));
	
	}

	public void click_car() {
		wd.findElement(car_link).click();

	}

	public void selectairport(String fromAirport ) throws InterruptedException {
		wd.findElement(FromAirport).click();
		wd.findElement(mumbai).sendKeys(fromAirport);
	    wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		wd.findElement(select2SearchField).sendKeys(Keys.ARROW_DOWN);
		 wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		wd.findElement(select2SearchField).sendKeys(Keys.ENTER);
		 wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	public void selectToLocation(String toLocation) throws InterruptedException {
		wd.findElement(ToAirport).click();
		wd.findElement(City_pune).sendKeys(toLocation);
		 wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		wd.findElement(select2SearchField).sendKeys(Keys.ARROW_DOWN);
		 wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		wd.findElement(select2SearchField).sendKeys(Keys.ENTER);
	}

	public void pickupdate() {
		wd.findElement(By.id("cars_from_date")).click();
		String d=wd.findElement(switchElement).getText();
		wd.findElement(dayDateElement).click();
	}

	public void toDate() {
		wd.findElement(By.id("cars_to_date")).click();
		wd.findElement(dropOffDateElement).click();
	}

	public void pickuptime() {
		WebElement Picktime=wd.findElement(By.id("cars_from_time"));
		Select select = new Select(Picktime);
		select.selectByValue("09:00");
	}

	public void droptime() {
		WebElement droptime=wd.findElement(By.id("cars_to_time"));
		Select select2 = new Select(droptime);
		select2.selectByValue("18:00");
	}

	public void search() throws InterruptedException {
		
		wd.findElement(search_Button).click();
   Thread.sleep(4000);
	}

}
