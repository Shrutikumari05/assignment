package com.Runner_Artifact;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
features = "src/test/resource/Featured_Flight.Booking_Filtered.feature",
glue = "com.stepDefination_Booking_Featured_Flight",
tags= "@Booking_with_ValidData" 
		)
		

public class Runner {

}
