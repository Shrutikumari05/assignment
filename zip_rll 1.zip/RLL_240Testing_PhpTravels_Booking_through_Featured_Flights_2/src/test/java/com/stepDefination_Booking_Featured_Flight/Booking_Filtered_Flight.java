package com.stepDefination_Booking_Featured_Flight;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight.BookingFilteredFlight_lib;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Booking_Filtered_Flight {
	
	WebDriver driver;
	BookingFilteredFlight_lib obj=new BookingFilteredFlight_lib();
	

  @Given("I am on the Featurd flight search page")
		public void i_am1(){
	  driver=new EdgeDriver();
	  obj.navigate_filterflight();
	}
	
	@Given("click on one way trip")
	public void click_on1() {
		obj.onway();
	}

	@When("^I entered in the (.*) and (.*) field$")
	public void i_enter1(String Flying,String Destination_field ) {
		obj.Flying();
        obj.destination();
	}
	
	
	
    @When("^I entered (.*) and one Traveller$")
    public void dep(String Departure_date) {
    	obj.date();
    }
    @When("I adjust a Price_range as per my requirement")
    public void i_adjust() {
    	System.
    	out
    	.println("I adjust a Price_range as per my requirement");
    }
    @When("I select Flight stops as Direct and click oneway Airline as a flydubai")
    public void i_select_stop() {
    	obj.stop();
    	obj.oneway_Airlines();
    }
    @When("^I selected (.*) from dropdown$")
    public void i_select_flight_class(String Flight_class) {
    	
    	obj.Flight_class();
    }
    @When("I select the first flight displayed")
    public void i_select_first() throws InterruptedException {
    	obj.Search();
    }
    @Then("I should see the Booking Flight page")
    public void i_should() {
    	  System.
    	  out
    	  .println("I should see the Booking Flight page");
    }
    @Then("I should see flights as per my requirement")
    public void should()  {
    	
    	System.
    	out
    
    .println("I should see flights as per my requirement");
   //valid
    
    }
    @Given("User is on Booking page of PHP Travels")
    public void booking_page() {
    	
    	System.
    	out
    	.println("User is on Booking page of PHP Travels");
    }
    @When("^User entered (.*) and (.*)$")
    public void firstname(String Firstname,String Lastname) {
    	
    	  obj.Firstname();
	        obj.lastname();
    }
    @When("^User entered (.*) and (.*)$")
    public void email(String Email,String Phone) {
    	
    	obj.email();
    	obj.phone();
    }
    @When("^User entered (.*)$")
    public void address(String Address) {
    	obj.address();
    }
    @When("^User entered (.*) and (.*)$")
    public void nationality(String Nationality1,String Current_Country) throws InterruptedException{
    	   obj.Nationality();
	       obj.currentCountry();
    }
    @When("^User entered (.*) from dropdown$")
    public void title(String Title) throws InterruptedException {
    	obj.Title();
    }
    @When("^User entered information as (.*) and (.*)$")
    public void info(String Traveller_Firstname,String Traveller_Lastname) {
    	obj.Fname();
        obj.Lname();
    }
    @When("^User entered (.*) and (.*) from dropdown$")
    public void dob(String Nationality,String Date_of_birth) {
    	obj.traveller_Nationality();
    	obj.dob();
    }
    @When("^User entered (.*) and (.*) from dropdown$")
    public void birth(String Birth_Day,String Birth_Year ) throws InterruptedException {
    	obj.Traveller_day();
        obj.traveller_year();
    }
    @When("^User entered (.*) within range$")
    public void passport(String Passport_ID) throws InterruptedException {
    	obj.passport();
    }
    @When("User entered Inssurance_date dropdown")
    public void inssu() {
    	System.
    	out
    	.println("User enter Inssurance_date dropdown");
    }
    @When("User entered Inssu_Day from dropdown")
    public void dropdown() {
    	System.
    	out
    	.println("User enter Inssu_Day from dropdown");
    }
    @When("^User entered (.*) from dropdown$")
    public void inssuyear(String Inssu_Year) throws InterruptedException {
    	obj.pass_issu_yr();
    }
    @When("User entered Expiry_Date from dropdown")
    public void expirydate() {
    	System.
    	out
    	.println("User enter Expiry_Date from dropdown");
    }
    @When("User entered Expiry_Day from dropdown")
    public void User_entered_Expiry_Day() {
    	System.
    	out
    	.println("User enter Expiry_Date from dropdown");
    } 
    @When("User entered Expiry_Year from dropdown")
    public void expiry_year() {System.
    	out
    	.println("User enter Expiry_Year from dropdown");}
    @When("User select payment method as Pay Later")
   public void payment() {obj.payment_method();}
    
    @When("User click on agree terms and conditions checkbox")
   
    
    public void agree() throws InterruptedException {obj.booking_done();}
    @When("User click on Booking confirm")
  
    
    public void booking_confirm() throws InterruptedException {obj.confirm_button();}
    @Then("Booking must be success")
   
    
    public void success() {
    	
    System.out.println("Booking must be success");
    }
 /*
    Examples:
      | Firstname | Lastname    | Email                             | Phone      | Address               | Nationality | Current_Country |Title| Traveller_Firstname | Traveller_Lastname | Nationality | Date_of_birth | Birth_Day | Birth_Year | Passport_ID |  Inssu_Year |  
      | Punam     | Suryawanshi | suryavanshi.1999.poonam@gmail.com | 9022769542 | Kharadi bypass, Pune | India       | India            |Miss  |Punam               | Suryawanshi        | India       | 12 Dec        |        14 |       1999 |      141414 |        2023 |
 */




	
	


















}
	
	
	
	    
	    
	/*    //invalid
	    
	        @Given("User on Booking page of PHP")
	        public void user_on_booking_page_of_php() {
	           System.out.println("User on Booking page of PHP");
	        }

	        @When("User enter {string} and {string} in field")
	        public void user_enter_firstname1_and_lastname1_in_field(String firstname1, String lastname1) {
	        	obj.Firstname();
		        obj.lastname();
	        }

	        @When("User enter {string} and {string} in field")
	        public void user_enter_email1_and_phone1_in_field(String email1, String phone1) {
	        	obj.email();
		    	obj.phone();
	        }

	        @When("User enter {string} in field")
	        public void user_enter_address1_in_field(String address1) {
	        	obj.address();
		        
	        }

	        @When("User enter {string} and {string} in field")
	        public void user_enter_nationality1_and_current_country1_in_field(String nationality1, String currentCountry1) {
	        	obj.traveller_Nationality();
		    	obj.dob();
	        }

	        @When("User enter {string} from dropdown of page")
	        public void user_enter_title1_from_dropdown_of_page(String title1) throws InterruptedException {
	        	obj.Title();
	        }

	        @When("User enter information as {string} and {string} in field")
	        public void user_enter_information_as_traveller_firstname1_and_traveller_lastname1_in_field(String travellerFirstname1, String travellerLastname1) {
	        	obj.Fname();
		        obj.Lname();
	        }

	        @When("User enter {string} and {string} from dropdown of page")
	        public void user_enter_nationality1_and_date_of_birth1_from_dropdown_of_page(String nationality1, String dateOfBirth1) {
	        	obj.traveller_Nationality();
		    	obj.dob();
	        }

	        @When("User enter {string} and {string} from dropdown of page")
	        public void user_enter_birth_day1_and_birth_year1_from_dropdown_of_page(String birthDay1, String birthYear1) {
	        	obj.Traveller_day();
		        obj.traveller_year();
	        }

	        @When("User enter {string} in field")
	        public void user_enter_passport_id1_in_field(String passportId1) {
	            
	        }

	        @When("User enter {string} dropdown of page")
	        public void user_enter_insurance_date1_dropdown_of_page(String insuranceDate1) {
	            
	        }

	        @When("User enter {string} from dropdown of page")
	        public void user_enter_insurance_day1_from_dropdown_of_page(String insuranceDay1) {
	            
	        }

	        @When("User enter {string} from dropdown of page")
	        public void user_enter_insurance_year1_from_dropdown_of_page(String insuranceYear1) {
	            
	        }

	        @When("User enter {string} from dropdown of page")
	        public void user_enter_expiry_date1_from_dropdown_of_page(String expiryDate1) {
	            
	        }

	        @When("User enter {string} from dropdown of page")
	        public void user_enter_expiry_day1_from_dropdown_of_page(String expiryDay1) {
	           
	        }

	        @When("User enter Expiry_Year1 from dropdown of page")
	        public void user_enter_expiry_year1_from_dropdown_of_page() {
	        	System.out.println();
	            
	        }

	        @When("User select payment method as Pay Later in booking page")
	        public void user_select_payment_method_as_pay_later_in_booking_page() {
	        	obj.payment_method();
	        }

	        @When("User click on agree terms and conditions checkbox in booking page")
	        public void user_click_on_agree_terms_and_conditions_checkbox_in_booking_page() throws InterruptedException {
	        	obj.booking_done();
	        }

	        @When("User click on Booking confirm button")
	        public void user_click_on_booking_confirm_button() throws InterruptedException {
	        	obj.confirm_button();
	        }

	        @Then("User will see Booking successful")
	        public void user_will_see_booking_successful() {
	        	System.out.println("User will see Booking successful");
	            
	        }
	 

//Null
	        
	       
	        
	            @Given("She is on Booking page of PHP")
	            public void she_is_on_booking_page_of_php() {
	                
	            }

	            @When("She enter {string} and {string}")
	            public void she_enter_firstname2_and_lastname2(String firstname2, String lastname2) {
	               
	            }

	            @When("She enter {string} and {string}")
	            public void she_enter_email2_and_phone2(String email2, String phone2) {
	               
	            }

	            @When("She enter {string}")
	            public void she_enter_address2(String address2) {
	                
	            }

	            @When("She enter {string} and {string}")
	            public void she_enter_nationality2_and_current_country2(String nationality2, String currentCountry2) {
	                
	            }

	            @When("She enter {string}")
	            public void she_enter_title2(String title2) {
	                
	            }

	            @When("She enter information as {string} and {string}")
	            public void she_enter_information_as_traveller_firstname2_and_traveller_lastname2(String travellerFirstname2, String travellerLastname2) {
	                
	            }

	            @When("She enter {string} and {string}")
	            public void she_enter_nationality2_and_date_of_birth2(String nationality2, String dateOfBirth2) {
	                
	            }

	            @When("She Select {string} and {string}")
	            public void she_select_birth_day2_and_birth_year2(String birthDay2, String birthYear2) {
	               
	            }

	            @When("She Select {string}")
	            public void she_select_passport_id2(String passportId2) {
	                
	            }

	            @When("She Select {string}")
	            public void she_select_insurance_date2(String insuranceDate2) {
	               
	            }

	            @When("She Select {string}")
	            public void she_select_insurance_day2(String insuranceDay2) {
	               
	            }

	            @When("She Select {string}")
	            public void she_select_insurance_year2(String insuranceYear2) {
	               
	            }

	            @When("She Select {string}")
	            public void she_select_expiry_date2(String expiryDate2) {
	                
	            }

	            @When("She Select {string}")
	            public void she_select_expiry_day2(String expiryDay2) {
	                
	            }

	            @When("She Select {string}")
	            public void she_select_expiry_year2(String expiryYear2) {
	               
	            }

	            @When("She select payment method as Pay Later")
	            public void she_select_payment_method_as_pay_later() {
	               
	            }

	            @When("She Select on agree terms and conditions checkbox")
	            public void she_select_on_agree_terms_and_conditions_checkbox() {
	               
	            }

	            @When("She Tick on Booking confirm")
	            public void she_tick_on_booking_confirm() {
	               
	            }

	            @Then("She get Booking must be success")
	            public void she_get_booking_must_be_success() {
	               
	            }
	        }
       

*/



	    
	    
	    
	    
	    
	    


	
	
	


