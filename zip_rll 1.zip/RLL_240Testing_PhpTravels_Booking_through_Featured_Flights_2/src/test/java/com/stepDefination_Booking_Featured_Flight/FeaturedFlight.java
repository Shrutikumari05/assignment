package com.stepDefination_Booking_Featured_Flight;

import org.openqa.selenium.WebDriver;

import com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight.FeaturedFlight_lib;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FeaturedFlight {
	
	WebDriver driver;
	FeaturedFlight_lib obj=new FeaturedFlight_lib();
	
	
	
	@Given("User on homepage of PHP Travels homepage")
    public void user_on_homepage_of_php_travels_homepage() {
        obj.Launch_app();
    }

    @When("User should see Featured Flight section")
    public void user_should_see_featured_flight_section() {
        System.out.println("Wel-Come");
    }

    @When("User select the first flight displayed")
    public void user_select_the_first_flight_displayed() {
        obj.flight_click();
    }

    @Then("User should see flight details page")
    public void user_should_see_flight_details_page() {
        System.out.println("This is list of Featured_Flights");
    }
}
    