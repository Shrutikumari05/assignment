package com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight;



import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class BookingFilteredFlight_lib {
	WebDriver driver; 
	By oneway=By.xpath("//small[text()='One Way']");
	By dropdown1=By.xpath("(//b[@role=\"presentation\"])[1]");
	By germany=By.xpath("(//small[text()=\"Germany\"])[2]");
	By dropdown2=By.xpath("(//b[@role=\"presentation\"])[2]");
	By Delhi=By.xpath("//small[text()=\"India\"]");
	By calendar=By.xpath("//input[@id=\"departure\"]");
	By Date=By.xpath("(//td[contains(text(),\"10\")])[1]");
	By stop=By.xpath("//input[@id=\"direct\"]");
	By Flight_class=By.xpath("//select[@id=\"flight_type\"]");
    By Firstclass=By.xpath("//option[contains(text(),\"First\")]");
    By oneway_airlines=By.xpath("//input[@id=\"oneway_flights_2\"]");
    By Search=By.xpath("//button[@id=\"flights-search\"]");
    By select=By.xpath("//button[contains(text(),\"Select Flight\")]");
    By Firstname=By.xpath("(//input[@type=\"text\" and @class=\" form-control\"])[1]");
    By lastname=By.xpath("(//input[@type=\"text\" and @class=\" form-control\"])[2]");
	By email=By.xpath("//input[@type=\"text\" and @placeholder=\"Email\"]");
	By phone=By.xpath("//input[@type=\"text\" and @placeholder=\"Phone\"]");
	By address1=By.xpath("//input[@type=\"text\" and @placeholder=\"Address\"]");
	By Nationality=By.xpath("(//button[@role=\"combobox\" and @type=\"button\"])[1]");
	By selectIndia=By.xpath("(//span[contains(text(),\"India\")])[2]");
	By currentCountry=By.xpath("(//button[@role=\"combobox\" and @type=\"button\"])[2]");
	By selectCountry=By.xpath("(//span[contains(text(),\"India\")])[4]");
	By Title=By.xpath("//select[@name=\"title_1\"]");
	By miss=By.xpath("//option[contains(text(),\"Miss\")]");
	By traveller_Fname=By.xpath("//input[@name=\"first_name_1\"]");
	By travleller_Lname=By.xpath("//input[@name=\"last_name_1\"]");
	By traveller_Nationality=By.xpath("//select[@name=\"nationality_1\"]");
	By select_traveller_nationality=By.xpath("(//option[contains(text(),\"India\")])[2]");
	By dob=By.xpath("//select[@name=\"dob_month_1\"]");
	By selectdob=By.xpath("//option[contains(text(),\"12 Dec\")][1]");
	By Traveller_day=By.xpath("//select[@name=\"dob_day_1\"]");
	By select_Traveller_day=By.xpath("(//option[contains(text(),\"14\")])[1]");
	By traveller_year=By.xpath("//select[@name=\"dob_year_1\"]");
	By select_traveller_year=By.xpath("(//option[contains(text(),\"1999\")])[1]");
	By passport=By.xpath("//input[@name=\"passport_1\"]");
	By pass_issu_yr=By.xpath("(//select[@class=\"form-select form-select\"])[6]");
	By select_pass_issu_yr=By.xpath("(//option[contains(text(),\"2023\")])[2]");
	By payment_method=By.xpath("(//div[@id=\"pills-home-tab\"])[3]");
	By agree=By.xpath("//input[@id=\"agreechb\"]");
	By confirm_button=By.xpath("//button[@id=\"booking\"]");
	
	
	
	
	

	public void init(WebDriver driver) {
		this.driver=driver;
		}
	
	public void navigate_filterflight() {
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://phptravels.net/flights");
		
		driver.navigate().to("https://phptravels.net/flights/lhe/dxb/oneway/economy/03-10-2024/1/0/0");
		
		driver.manage().window().maximize();
		
	}
	public void onway() {
		
		driver.findElement(oneway).click();
		
	}	
	public void Flying() {
		driver.findElement(dropdown1).click();
		driver.findElement(germany).click();
	
		}
	 public void destination() {
		
		
        driver.findElement(dropdown2).click();
		driver.findElement(Delhi).click();	
	
}
	 public void date() {
		
		driver.findElement(calendar).click();
		driver.findElement(Date).click();
		
	}
	 public void stop() {
		 
		 driver.findElement(stop).click();
	 }
	 
	 public void Flight_class() {
		
		 driver.findElement(Flight_class).click();
		 
		 driver.findElement(Firstclass).click();
		 
	 }
	 public void oneway_Airlines() {
		 
		driver.findElement(oneway_airlines).click();
	 
}
	
	 public void Search() throws InterruptedException {
		 
		driver.findElement(Search).click();
		Thread.sleep(3000);
	  driver.findElement(select).click();
}
	public void Firstname()  {
		
		
		
	driver.findElement(Firstname).sendKeys("Punam");
	
	
	}
	public void lastname() {
		driver.findElement(lastname).sendKeys("Suryawanshi");}
	
	
	public void email() {
		driver.findElement(email).sendKeys("suryavanshi.1999.poonam@gmail.com");}
	public void phone() {
		driver.findElement(phone).sendKeys("9022769542");}
	
	
	public void address() {
		driver.findElement(address1).sendKeys("Kharadi bypass, Pune");}
	
	public void Nationality() throws InterruptedException {
		driver.findElement(Nationality).click();
		Thread.sleep(3000);
		driver.findElement(selectIndia).click();}
		
	
	
	public void currentCountry() throws InterruptedException {
		driver.findElement(currentCountry).click();
		Thread.sleep(3000);
		driver.findElement(selectCountry).click();}
	
	public void Title() throws InterruptedException {
	Thread.sleep(3000);
		driver.findElement(Title).click();
	Thread.sleep(3000);
		driver.findElement(miss).click();}
	
	
	
	public void Fname() {
		driver.findElement(traveller_Fname).sendKeys("Punam");}
	
	
	public void Lname() {
		driver.findElement(travleller_Lname).sendKeys("Suryawanshi");}
	
	public void traveller_Nationality() {
		driver.findElement(traveller_Nationality).click();
		driver.findElement(select_traveller_nationality).click();}
	
	public void dob() {
		driver.findElement(dob).click();
		driver.findElement(selectdob).click();}
	
	public void Traveller_day() {
		driver.findElement(Traveller_day).click();
		driver.findElement(select_Traveller_day).click();}
	
	public void traveller_year() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(traveller_year).click();
		driver.findElement(select_traveller_year).click();}
	
	public void passport() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(passport).sendKeys("141414");}
	
	public void pass_issu_yr() throws InterruptedException {
		driver.findElement(pass_issu_yr).click();
		Thread.sleep(3000);
		driver.findElement(select_pass_issu_yr).click();
		Thread.sleep(3000);}
	
	public void payment_method() {
	    driver.findElement(payment_method).click();

		
		}
	 
	public void booking_done() throws InterruptedException{
		
		Thread.sleep(4500);

		driver.findElement(agree).click();
	}
		public void confirm_button() throws InterruptedException {
		Thread.sleep(4500);
		driver.findElement(confirm_button).click();

		
}}