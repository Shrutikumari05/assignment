package com.pages.RLL_240Testing_PhpTravels_Booking_through_Featured_Flight;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FeaturedFlight_lib {

	
	
	WebDriver driver;

	By Flight_Click=By.xpath("//a[contains(text(),\"Flights\")]");
	By lahor_dubai_click=By.xpath("//strong[contains(text(),\"Lahore\")]");

	public void init(WebDriver driver) {
		this.driver=driver;
	}
	public void Launch_app() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://phptravels.net/");
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/flights");
	}


	public void flight_click()  {
	driver.findElement(Flight_Click).click();
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
	
		e.printStackTrace();
	}
	
	
	
	driver.findElement(lahor_dubai_click).click();
	

	}
	
	

	}

