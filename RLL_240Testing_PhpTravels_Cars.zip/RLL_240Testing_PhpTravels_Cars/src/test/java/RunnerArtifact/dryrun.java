package RunnerArtifact;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_PhpTravels_Cars.PhpTravels_SearchCars_lib;

public class dryrun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver wd;
		wd=new ChromeDriver();
		PhpTravels_SearchCars_lib obj=new PhpTravels_SearchCars_lib (wd);
		obj.launch();
		obj.click_car();

	}

}
