package com.pages.RLL_240Testing_PhpTravels_Cars;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PhpTravels_SearchCars_lib {

	WebDriver wd;
	
	//Locators
	By car_link = By.xpath("//a[contains(text(),\"Cars\")]");
	By FromAirport=By.xpath("//div[@class=\"mt-1\"]");
	By	ToAirport=By.xpath("//span[contains(text(),\"Select\")]");
	By	PickupDate=By.xpath("//input[@id=\"cars_from_date\"]");
//	By	pickpTime=By.xpath("//select[@id=\"cars_from_time\"]");
	By	DropOffDate =By.xpath("//input[@id=\"cars_to_date\"]");
//	By	DropOffTime=By.xpath("//select[@id=\"cars_to_time\"]");
	By	traveller=By.xpath("//p[@class=\"m-0 d-flex align-items-center gap-2\"]");
	By	search_Button=By.xpath("//button[@class=\"search_button w-100 btn btn-primary btn-m rounded-sm font-700 text-uppercase btn-full waves-effect\"and @type=\"submit\"]");
	By mumbai=By.xpath("//input[@class=\"select2-search__field\" and @type=\"search\"]");
	By City_pune=By.xpath("//input[@class=\"select2-search__field\" and @type =\"search\"]");
	
	By select2SearchField = By.xpath("//input[@class=\"select2-search__field\" and @type=\"search\"]");
    By switchElement = By.xpath("(//th[@class=\"switch\"])[1]");
	By dayDateElement = By.xpath("(//td[@class=\"day \"])[9]");
	By dropOffDateElement = By.xpath("//*[@id=\"fadein\"]/div[6]/div[1]/table/tbody/tr[3]/td[3]");

	public PhpTravels_SearchCars_lib(WebDriver wd) {
		this.wd=wd;
	}
	
	public void launch() throws InterruptedException {
		wd = new ChromeDriver();
		Thread.sleep(500);
		wd.get("https://phptravels.net/");
		wd.manage().window().maximize();
	}
	public void click_car() {
		wd.findElement(car_link).click();
		
	}
	public void fillDetails() throws InterruptedException {
		wd.findElement(FromAirport).click();
		wd.findElement(mumbai).sendKeys("mumbai");
		Thread.sleep(500);
		wd.findElement(select2SearchField).sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(500);
		wd.findElement(select2SearchField).sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		wd.findElement(ToAirport).click();
		wd.findElement(City_pune).sendKeys("pune");
		Thread.sleep(500);
		wd.findElement(select2SearchField).sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(500);
		wd.findElement(select2SearchField).sendKeys(Keys.ENTER);
		
		wd.findElement(By.id("cars_from_date")).click();
		String d=wd.findElement(switchElement).getText();
		
		wd.findElement(dayDateElement ).click();
		
		wd.findElement(By.id("cars_to_date")).click();
		wd.findElement(dropOffDateElement).click();
		
		WebElement Picktime=wd.findElement(By.id("cars_from_time"));
		Select select = new Select(Picktime);
		select.selectByValue("09:00");
		
		WebElement droptime=wd.findElement(By.id("cars_to_time"));
		Select select2 = new Select(droptime);
		select2.selectByValue("18:00");
		
		wd.findElement(search_Button).click();
	}
}
