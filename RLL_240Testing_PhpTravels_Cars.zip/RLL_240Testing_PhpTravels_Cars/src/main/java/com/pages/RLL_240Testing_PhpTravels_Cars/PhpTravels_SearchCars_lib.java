package com.pages.RLL_240Testing_PhpTravels_Cars;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PhpTravels_SearchCars_lib {

	WebDriver wd;
	
	//Locators
	By car_link = By.xpath("//a[contains(text(),\"Cars\")]");
	By FromAirport=By.xpath("//div[@class=\"mt-1\"]");
	By	ToAirport=By.xpath("//b[@role=\"presentation\"])[2]");
	By	PickupDate=By.xpath("//input[@id=\"cars_from_date\"]");
	By	pickpTime=By.xpath("//select[@id=\"cars_from_time\"]");
	By	DropOffDate =By.xpath("//input[@id=\"cars_to_date\"]");
	By	DropOffTime=By.xpath("//select[@id=\"cars_to_time\"]");
	By	traveller=By.xpath("//p[@class=\"m-0 d-flex align-items-center gap-2\"]");
	By	search_Button=By.xpath("//button[@type=\"submit\"])[1]");

	public PhpTravels_SearchCars_lib(WebDriver wd) {
		this.wd=wd;
	}
	
	public void launch() {
		wd.get("https://phptravels.net/");
		wd.manage().window().maximize();
	}
	public void click_car() {
		wd.findElement(car_link).click();
		
	}
}
